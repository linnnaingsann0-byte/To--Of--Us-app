import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { L as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as ImagePlus, a as Trash2, b as Check, c as Plus, d as PhoneOff, f as NotebookPen, g as Image, h as MessageCircle, l as Pin, m as MicOff, n as Video, o as Settings, p as Mic, r as VideoOff, s as Send, t as X, u as Phone, v as Heart, y as Film } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Z4N11j_o.js
var routes_Z4N11j_o_exports = /* @__PURE__ */ __exportAll({
	a: () => downloadBlob,
	component: () => Home,
	i: () => dataUrlToBlob,
	n: () => chunkDataUrl,
	r: () => compressImage,
	t: () => blobToDataUrl
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function compressImage(file, max = 1400, quality = .82) {
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) return file;
	ctx.drawImage(bitmap, 0, 0, w, h);
	bitmap.close();
	return await new Promise((res) => canvas.toBlob(res, "image/jpeg", quality)) ?? file;
}
async function blobToDataUrl(blob) {
	return await new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(blob);
	});
}
function dataUrlToBlob(dataUrl) {
	const [head, body] = dataUrl.split(",");
	const mime = /data:([^;]+)/.exec(head)?.[1] ?? "application/octet-stream";
	const bin = atob(body ?? "");
	const bytes = new Uint8Array(bin.length);
	for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
	return new Blob([bytes], { type: mime });
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	setTimeout(() => URL.revokeObjectURL(url), 1500);
}
var CHUNK = 12e3;
function chunkDataUrl(dataUrl) {
	const chunks = [];
	for (let i = 0; i < dataUrl.length; i += CHUNK) chunks.push(dataUrl.slice(i, i + CHUNK));
	return chunks;
}
var ACCENT_PRESETS = [
	{
		id: "rose",
		hex: "#c45c6a"
	},
	{
		id: "clay",
		hex: "#b5694a"
	},
	{
		id: "sage",
		hex: "#5f7f68"
	},
	{
		id: "ocean",
		hex: "#4a7384"
	},
	{
		id: "ink",
		hex: "#8a827a"
	}
];
var DEFAULT_SETTINGS = {
	lang: "my",
	accent: "#c45c6a",
	wallpaperDim: .55,
	coupleCode: "",
	me: { name: "" },
	partner: { name: "" },
	activeRole: "me",
	onboarded: false
};
var DB_NAME = "two-of-us";
var DB_VER = 1;
var dbPromise = null;
function openDb() {
	if (typeof indexedDB === "undefined") return Promise.reject(/* @__PURE__ */ new Error("no indexedDB"));
	if (dbPromise) return dbPromise;
	dbPromise = new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, DB_VER);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
			if (!db.objectStoreNames.contains("blobs")) db.createObjectStore("blobs");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => {
			dbPromise = null;
			reject(req.error);
		};
	});
	return dbPromise;
}
function txDone(tx) {
	return new Promise((resolve, reject) => {
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
		tx.onabort = () => reject(tx.error);
	});
}
async function kvGet(key) {
	try {
		const db = await openDb();
		return await new Promise((resolve, reject) => {
			const req = db.transaction("kv", "readonly").objectStore("kv").get(key);
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
	} catch {
		return;
	}
}
async function kvSet(key, value) {
	try {
		const tx = (await openDb()).transaction("kv", "readwrite");
		tx.objectStore("kv").put(value, key);
		await txDone(tx);
	} catch {}
}
async function blobPut(id, blob) {
	const tx = (await openDb()).transaction("blobs", "readwrite");
	tx.objectStore("blobs").put(blob, id);
	await txDone(tx);
}
async function blobGet(id) {
	try {
		const db = await openDb();
		return await new Promise((resolve, reject) => {
			const req = db.transaction("blobs", "readonly").objectStore("blobs").get(id);
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => reject(req.error);
		});
	} catch {
		return;
	}
}
async function blobDel(id) {
	try {
		const tx = (await openDb()).transaction("blobs", "readwrite");
		tx.objectStore("blobs").delete(id);
		await txDone(tx);
	} catch {}
}
var urlCache = /* @__PURE__ */ new Map();
async function blobUrl(id) {
	const cached = urlCache.get(id);
	if (cached) return cached;
	const blob = await blobGet(id);
	if (!blob) return void 0;
	const url = URL.createObjectURL(blob);
	urlCache.set(id, url);
	return url;
}
function blobUrlForget(id) {
	const url = urlCache.get(id);
	if (url) {
		URL.revokeObjectURL(url);
		urlCache.delete(id);
	}
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function coupleCode() {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
	let out = "";
	for (let i = 0; i < 6; i++) out += alphabet[Math.floor(Math.random() * 32)];
	return out;
}
function accentForeground(hex) {
	const raw = hex.replace("#", "");
	if (raw.length !== 6) return "#f3ece4";
	const n = parseInt(raw, 16);
	const r = n >> 16 & 255;
	const g = n >> 8 & 255;
	const b = n & 255;
	return (.2126 * r + .7152 * g + .0722 * b) / 255 > .62 ? "#14110f" : "#f3ece4";
}
var LOCALE = {
	en: "en-US",
	my: "my-MM",
	th: "th-TH"
};
function formatTime(ts, lang) {
	return new Intl.DateTimeFormat(LOCALE[lang], {
		hour: "numeric",
		minute: "2-digit"
	}).format(ts);
}
function formatDay(ts, lang) {
	const d = new Date(ts);
	const now = /* @__PURE__ */ new Date();
	const start = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
	const diff = start(now) - start(d);
	if (diff === 0) return lang === "my" ? "ယနေ့" : lang === "th" ? "วันนี้" : "Today";
	if (diff === 864e5) return lang === "my" ? "မနေ့က" : lang === "th" ? "เมื่อวาน" : "Yesterday";
	return new Intl.DateTimeFormat(LOCALE[lang], {
		month: "short",
		day: "numeric",
		year: "numeric"
	}).format(d);
}
function formatDuration(ms) {
	const s = Math.max(0, Math.floor(ms / 1e3));
	const m = Math.floor(s / 60);
	const r = s % 60;
	return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
async function persistAll(get) {
	const { settings, messages, photos, videos, notes } = get();
	await Promise.all([
		kvSet("settings", settings),
		kvSet("messages", messages),
		kvSet("photos", photos),
		kvSet("videos", videos),
		kvSet("notes", notes)
	]);
}
var useApp = create((set, get) => ({
	ready: false,
	tab: "chat",
	settings: {
		...DEFAULT_SETTINGS,
		coupleCode: ""
	},
	messages: [],
	photos: [],
	videos: [],
	notes: [],
	call: {
		phase: "idle",
		kind: "audio"
	},
	hydrate: async () => {
		const [settings, messages, photos, videos, notes] = await Promise.all([
			kvGet("settings"),
			kvGet("messages"),
			kvGet("photos"),
			kvGet("videos"),
			kvGet("notes")
		]);
		const next = {
			...DEFAULT_SETTINGS,
			...settings ?? {},
			me: {
				...DEFAULT_SETTINGS.me,
				...settings?.me ?? {}
			},
			partner: {
				...DEFAULT_SETTINGS.partner,
				...settings?.partner ?? {}
			},
			coupleCode: settings?.coupleCode || coupleCode()
		};
		if (!ACCENT_PRESETS.some((p) => p.hex === next.accent) && !/^#[0-9a-fA-F]{6}$/.test(next.accent)) next.accent = DEFAULT_SETTINGS.accent;
		set({
			settings: next,
			messages: messages ?? [],
			photos: photos ?? [],
			videos: videos ?? [],
			notes: notes ?? [],
			ready: true
		});
		if (!settings) await kvSet("settings", next);
	},
	setTab: (tab) => set({ tab }),
	patchSettings: (partial) => {
		set((s) => ({ settings: {
			...s.settings,
			...partial
		} }));
		persistAll(get);
	},
	setPerson: (role, partial) => {
		set((s) => ({ settings: {
			...s.settings,
			[role]: {
				...s.settings[role],
				...partial
			}
		} }));
		persistAll(get);
	},
	setAvatar: async (role, file) => {
		const blob = await compressImage(file, 480, .85);
		const id = uid("ava");
		await blobPut(id, blob);
		const prev = get().settings[role].avatarId;
		set((s) => ({ settings: {
			...s.settings,
			[role]: {
				...s.settings[role],
				avatarId: id
			}
		} }));
		if (prev) {
			blobUrlForget(prev);
			blobDel(prev);
		}
		persistAll(get);
	},
	setWallpaper: async (file) => {
		const prev = get().settings.wallpaperId;
		if (!file) {
			set((s) => ({ settings: {
				...s.settings,
				wallpaperId: void 0
			} }));
			if (prev) {
				blobUrlForget(prev);
				blobDel(prev);
			}
			persistAll(get);
			return;
		}
		const blob = await compressImage(file, 1800, .8);
		const id = uid("wall");
		await blobPut(id, blob);
		set((s) => ({ settings: {
			...s.settings,
			wallpaperId: id
		} }));
		if (prev) {
			blobUrlForget(prev);
			blobDel(prev);
		}
		persistAll(get);
	},
	sendMessage: async (text, media) => {
		const { settings } = get();
		let mediaId;
		let mediaKind;
		if (media) {
			const blob = media.kind === "image" ? await compressImage(media.blob) : media.blob;
			mediaId = uid("med");
			await blobPut(mediaId, blob);
			mediaKind = media.kind;
		}
		const msg = {
			id: uid("msg"),
			from: settings.activeRole,
			text: text.trim(),
			mediaId,
			mediaKind,
			createdAt: Date.now()
		};
		set((s) => ({ messages: [...s.messages, msg] }));
		persistAll(get);
		return msg;
	},
	ingestRemoteMessage: async (msg, mediaDataUrl) => {
		if (get().messages.some((m) => m.id === msg.id)) return;
		if (mediaDataUrl && msg.mediaId) {
			const { dataUrlToBlob } = await import("./media-fDxHknzV.mjs");
			await blobPut(msg.mediaId, dataUrlToBlob(mediaDataUrl));
		}
		set((s) => ({ messages: [...s.messages, msg].sort((a, b) => a.createdAt - b.createdAt) }));
		persistAll(get);
	},
	saveMessageMedia: async (messageId) => {
		const msg = get().messages.find((m) => m.id === messageId);
		if (!msg?.mediaId || !msg.mediaKind) return;
		const item = {
			id: uid("alb"),
			blobId: msg.mediaId,
			kind: msg.mediaKind,
			caption: msg.text,
			createdAt: msg.createdAt,
			from: msg.from
		};
		if (msg.mediaKind === "image") set((s) => ({
			photos: [item, ...s.photos],
			messages: s.messages.map((m) => m.id === messageId ? {
				...m,
				saved: true
			} : m)
		}));
		else set((s) => ({
			videos: [item, ...s.videos],
			messages: s.messages.map((m) => m.id === messageId ? {
				...m,
				saved: true
			} : m)
		}));
		persistAll(get);
	},
	addAlbum: async (kind, file, caption, from) => {
		const blob = kind === "image" ? await compressImage(file) : file;
		const blobId = uid("med");
		await blobPut(blobId, blob);
		const item = {
			id: uid("alb"),
			blobId,
			kind,
			caption,
			createdAt: Date.now(),
			from
		};
		if (kind === "image") set((s) => ({ photos: [item, ...s.photos] }));
		else set((s) => ({ videos: [item, ...s.videos] }));
		persistAll(get);
		return item;
	},
	updateCaption: (kind, id, caption) => {
		set((s) => ({ [kind]: s[kind].map((it) => it.id === id ? {
			...it,
			caption
		} : it) }));
		persistAll(get);
	},
	removeAlbum: async (kind, id) => {
		const item = get()[kind].find((x) => x.id === id);
		set((s) => ({ [kind]: s[kind].filter((x) => x.id !== id) }));
		if (item) {
			if (!(get().messages.some((m) => m.mediaId === item.blobId) || get().photos.some((p) => p.blobId === item.blobId) || get().videos.some((p) => p.blobId === item.blobId))) {
				blobUrlForget(item.blobId);
				blobDel(item.blobId);
			}
		}
		persistAll(get);
	},
	addNote: (title, body) => {
		const note = {
			id: uid("note"),
			title: title.trim() || "",
			body: body.trim(),
			pinned: false,
			createdAt: Date.now(),
			updatedAt: Date.now()
		};
		set((s) => ({ notes: [note, ...s.notes] }));
		persistAll(get);
		return note;
	},
	updateNote: (id, patch) => {
		set((s) => ({ notes: s.notes.map((n) => n.id === id ? {
			...n,
			...patch,
			updatedAt: Date.now()
		} : n) }));
		persistAll(get);
	},
	removeNote: (id) => {
		set((s) => ({ notes: s.notes.filter((n) => n.id !== id) }));
		persistAll(get);
	},
	applyRemoteNotes: (notes) => {
		set((s) => {
			const map = new Map(s.notes.map((n) => [n.id, n]));
			for (const n of notes) {
				const existing = map.get(n.id);
				if (!existing || n.updatedAt >= existing.updatedAt) map.set(n.id, n);
			}
			return { notes: [...map.values()].sort((a, b) => b.updatedAt - a.updatedAt) };
		});
		persistAll(get);
	},
	applyRemoteAlbum: async (item, dataUrl) => {
		if (get().photos.some((p) => p.id === item.id) || get().videos.some((v) => v.id === item.id)) return;
		const { dataUrlToBlob } = await import("./media-fDxHknzV.mjs");
		await blobPut(item.blobId, dataUrlToBlob(dataUrl));
		if (item.kind === "image") set((s) => ({ photos: [item, ...s.photos] }));
		else set((s) => ({ videos: [item, ...s.videos] }));
		persistAll(get);
	},
	startCall: (kind) => set({ call: {
		phase: "outgoing",
		kind
	} }),
	receiveCall: (kind) => set({ call: {
		phase: "incoming",
		kind
	} }),
	acceptCall: () => set({ call: {
		phase: "active",
		kind: get().call.kind,
		startedAt: Date.now()
	} }),
	endCall: () => set({ call: {
		phase: "idle",
		kind: get().call.kind
	} })
}));
var strings = {
	en: {
		appName: "Two of Us",
		tagline: "A private space for the two of you",
		chat: "Chat",
		photos: "Photos",
		videos: "Videos",
		notes: "Notes",
		settings: "Settings",
		typeMessage: "Write something…",
		send: "Send",
		attachPhoto: "Photo",
		attachVideo: "Video",
		saveToPhotos: "Save to photos",
		saveToVideos: "Save to videos",
		saved: "Saved",
		call: "Call",
		videoCall: "Video",
		endCall: "End",
		mute: "Mute",
		unmute: "Unmute",
		cameraOn: "Camera on",
		cameraOff: "Camera off",
		incomingCall: "Incoming call",
		outgoingCall: "Calling…",
		accept: "Accept",
		decline: "Decline",
		ringing: "Ringing",
		waiting: "Waiting",
		connected: "Connected",
		connecting: "Connecting",
		callEnded: "Call ended",
		microphoneBlocked: "Microphone permission is needed for a call.",
		cameraBlocked: "Camera permission is needed for video.",
		addPhoto: "Add photo",
		addVideo: "Add video",
		addNote: "New note",
		caption: "Caption",
		title: "Title",
		body: "Write it down",
		pin: "Pin",
		unpin: "Unpin",
		delete: "Delete",
		edit: "Edit",
		cancel: "Cancel",
		save: "Save",
		done: "Done",
		emptyPhotos: "The photos you want to keep will live here.",
		emptyVideos: "The videos you want to keep will live here.",
		emptyNotes: "Dates, promises, little things you must not forget.",
		emptyChat: "Say the first thing.",
		language: "Language",
		themeColor: "Theme color",
		background: "Background",
		changeBackground: "Choose a photo",
		resetBackground: "Use default",
		backgroundDim: "Dim overlay",
		myName: "Your name",
		partnerName: "Their name",
		myPhoto: "Your photo",
		partnerPhoto: "Their photo",
		coupleCode: "Couple code",
		copyCode: "Copy",
		copied: "Copied",
		shareHint: "Share this code. Open the same app on their phone and enter it to chat and call.",
		waitingPartner: "Waiting for them to join",
		partnerOnline: "Together now",
		sendingAs: "Sending as",
		switchHint: "Tap a name to send as you or as them — useful on one shared phone.",
		onboardingTitle: "Two of Us",
		onboardingSub: "Your names, then a quiet place that is only yours.",
		continue: "Continue",
		start: "Begin",
		pickLanguage: "Language",
		whoAmI: "This phone belongs to",
		iAmMe: "Me",
		iAmPartner: "Them",
		newNote: "New note",
		download: "Download",
		close: "Close",
		english: "English",
		myanmar: "မြန်မာ",
		thai: "ไทย",
		colorPresets: "Presets",
		wallpaperHint: "Any photo you love can be the room behind everything.",
		important: "Remember",
		fromMe: "From me",
		fromThem: "From them",
		all: "All",
		enterCode: "Join with their code",
		applyCode: "Join",
		codeInvalid: "Use 4–8 letters or numbers.",
		previewCall: "Your camera is on. They will appear when they join with the couple code.",
		noPeerCall: "Ringing on this phone until they join."
	},
	my: {
		appName: "နှစ်ယောက်",
		tagline: "ငါတို့နှစ်ယောက်ရဲ့ ကိုယ်ပိုင်နေရာ",
		chat: "စကားပြော",
		photos: "ဓာတ်ပုံ",
		videos: "ဗီဒီယို",
		notes: "မှတ်စု",
		settings: "စက်တင်",
		typeMessage: "စာရိုက်ပါ…",
		send: "ပို့မည်",
		attachPhoto: "ဓာတ်ပုံ",
		attachVideo: "ဗီဒီယို",
		saveToPhotos: "ဓာတ်ပုံထဲ သိမ်းမည်",
		saveToVideos: "ဗီဒီယိုထဲ သိမ်းမည်",
		saved: "သိမ်းပြီးပါပြီ",
		call: "ဖုန်းခေါ်",
		videoCall: "ဗီဒီယိုခေါ်",
		endCall: "ချလိုက်မည်",
		mute: "မိုက်ပိတ်",
		unmute: "မိုက်ဖွင့်",
		cameraOn: "ကင်မရာဖွင့်",
		cameraOff: "ကင်မရာပိတ်",
		incomingCall: "ဖုန်းလာသည်",
		outgoingCall: "ခေါ်နေသည်…",
		accept: "ခံမည်",
		decline: "ငြင်းမည်",
		ringing: "မြည်နေသည်",
		waiting: "စောင့်နေသည်",
		connected: "ချိတ်ဆက်ပြီး",
		connecting: "ချိတ်ဆက်နေသည်",
		callEnded: "ခေါ်ဆိုမှု ပြီးပါပြီ",
		microphoneBlocked: "ဖုန်းခေါ်ရန် မိုက်ခွင့်ပြုရန် လိုသည်။",
		cameraBlocked: "ဗီဒီယိုခေါ်ရန် ကင်မရာခွင့်ပြုရန် လိုသည်။",
		addPhoto: "ဓာတ်ပုံထည့်မည်",
		addVideo: "ဗီဒီယိုထည့်မည်",
		addNote: "မှတ်စုအသစ်",
		caption: "မှတ်ချက်",
		title: "ခေါင်းစဉ်",
		body: "ရေးသားရန်",
		pin: "ပင်တွဲမည်",
		unpin: "ပင်ဖြုတ်မည်",
		delete: "ဖျက်မည်",
		edit: "ပြင်မည်",
		cancel: "မလုပ်တော့",
		save: "သိမ်းမည်",
		done: "ပြီးပါပြီ",
		emptyPhotos: "အမှတ်တရ ဓာတ်ပုံတွေကို ဒီမှာ သိမ်းပါ။",
		emptyVideos: "အမှတ်တရ ဗီဒီယိုတွေကို ဒီမှာ သိမ်းပါ။",
		emptyNotes: "မမေ့သင့်တဲ့ ရက်စွဲ၊ ကတိ၊ အရေးကြီးတာတွေ။",
		emptyChat: "ပထမဆုံး စာစတင် ပို့လိုက်ပါ။",
		language: "ဘာသာစကား",
		themeColor: "အပြင်အဆင် အရောင်",
		background: "နောက်ခံပုံ",
		changeBackground: "ပုံရွေးမည်",
		resetBackground: "မူလပုံ ပြန်ထားမည်",
		backgroundDim: "နောက်ခံ မှိန်မှု",
		myName: "သင့်နာမည်",
		partnerName: "ချစ်သူနာမည်",
		myPhoto: "သင့်ဓာတ်ပုံ",
		partnerPhoto: "ချစ်သူဓာတ်ပုံ",
		coupleCode: "တွဲကုဒ်",
		copyCode: "ကူးယူမည်",
		copied: "ကူးပြီးပါပြီ",
		shareHint: "ဒီကုဒ်ကို ချစ်သူဆီ ပို့ပါ။ သူ့ဖုန်းမှာ ဒီအက်ပ်ဖွင့်ပြီး ထည့်လိုက်ရင် စကားပြော၊ ဖုန်းခေါ်လို့ ရပါပြီ။",
		waitingPartner: "ချစ်သူ ချိတ်ဆက်လာမည်ကို စောင့်နေသည်",
		partnerOnline: "အတူတူ ရောက်နေပြီ",
		sendingAs: "ပို့နေသူ",
		switchHint: "နာမည်ကို နှိပ်ပြီး ကိုယ့်ဘက်က ပို့မလား ချစ်သူဘက်က ပို့မလား ပြောင်းနိုင်သည်။ ဖုန်းတစ်လုံးတည်း သုံးရင် အဆင်ပြေသည်။",
		onboardingTitle: "နှစ်ယောက်",
		onboardingSub: "နာမည်လေးတွေ ထည့်ပြီး ငါတို့ရဲ့ နေရာလေး စတင်လိုက်ပါ။",
		continue: "ရှေ့ဆက်မည်",
		start: "စတင်မည်",
		pickLanguage: "ဘာသာစကား",
		whoAmI: "ဒီဖုန်းက ဘယ်သူလဲ",
		iAmMe: "ကိုယ်",
		iAmPartner: "ချစ်သူ",
		newNote: "မှတ်စုအသစ်",
		download: "ဒေါင်းလုပ်",
		close: "ပိတ်မည်",
		english: "English",
		myanmar: "မြန်မာ",
		thai: "ไทย",
		colorPresets: "အရောင်များ",
		wallpaperHint: "နှစ်သက်ရာ ပုံကို နောက်ခံအဖြစ် ပြောင်းနိုင်သည်။",
		important: "အမှတ်ရ",
		fromMe: "ကိုယ့်ဘက်",
		fromThem: "ချစ်သူဘက်",
		all: "အားလုံး",
		enterCode: "သူ့ကုဒ်ဖြင့် ဝင်မည်",
		applyCode: "ဝင်မည်",
		codeInvalid: "စာလုံး သို့မဟုတ် ဂဏန်း ၄–၈ လုံး ထည့်ပါ။",
		previewCall: "ကင်မရာ ဖွင့်ထားသည်။ တွဲကုဒ်ဖြင့် သူချိတ်လာရင် ပေါ်လာပါမည်။",
		noPeerCall: "သူမချိတ်မချင်း ဒီဖုန်းမှာ မြည်နေမည်။"
	},
	th: {
		appName: "เราทั้งคู่",
		tagline: "พื้นที่ส่วนตัวของสองคน",
		chat: "แชท",
		photos: "รูปภาพ",
		videos: "วิดีโอ",
		notes: "บันทึก",
		settings: "ตั้งค่า",
		typeMessage: "พิมพ์ข้อความ…",
		send: "ส่ง",
		attachPhoto: "รูป",
		attachVideo: "วิดีโอ",
		saveToPhotos: "บันทึกลงอัลบั้มรูป",
		saveToVideos: "บันทึกลงอัลบั้มวิดีโอ",
		saved: "บันทึกแล้ว",
		call: "โทร",
		videoCall: "วิดีโอคอล",
		endCall: "วางสาย",
		mute: "ปิดไมค์",
		unmute: "เปิดไมค์",
		cameraOn: "เปิดกล้อง",
		cameraOff: "ปิดกล้อง",
		incomingCall: "สายเรียกเข้า",
		outgoingCall: "กำลังโทร…",
		accept: "รับสาย",
		decline: "ปฏิเสธ",
		ringing: "กำลังดัง",
		waiting: "รอสาย",
		connected: "เชื่อมต่อแล้ว",
		connecting: "กำลังเชื่อมต่อ",
		callEnded: "จบการโทร",
		microphoneBlocked: "ต้องอนุญาตไมโครโฟนเพื่อโทร",
		cameraBlocked: "ต้องอนุญาตกล้องสำหรับวิดีโอคอล",
		addPhoto: "เพิ่มรูป",
		addVideo: "เพิ่มวิดีโอ",
		addNote: "บันทึกใหม่",
		caption: "คำบรรยาย",
		title: "หัวข้อ",
		body: "เขียนที่นี่",
		pin: "ปักหมุด",
		unpin: "เอาหมุดออก",
		delete: "ลบ",
		edit: "แก้ไข",
		cancel: "ยกเลิก",
		save: "บันทึก",
		done: "เสร็จ",
		emptyPhotos: "รูปที่อยากเก็บความทรงจำ จะอยู่ที่นี่",
		emptyVideos: "คลิปที่อยากเก็บความทรงจำ จะอยู่ที่นี่",
		emptyNotes: "วันสำคัญ คำสัญญา สิ่งที่ห้ามลืม",
		emptyChat: "ทักทายกันสักคำ",
		language: "ภาษา",
		themeColor: "สีธีม",
		background: "พื้นหลัง",
		changeBackground: "เลือกภาพ",
		resetBackground: "ใช้ภาพเดิม",
		backgroundDim: "ความมืดของพื้นหลัง",
		myName: "ชื่อของคุณ",
		partnerName: "ชื่อคนรัก",
		myPhoto: "รูปของคุณ",
		partnerPhoto: "รูปคนรัก",
		coupleCode: "รหัสคู่",
		copyCode: "คัดลอก",
		copied: "คัดลอกแล้ว",
		shareHint: "ส่งรหัสนี้ให้กัน เปิดแอปเครื่องนั้นแล้วกรอกรหัสเดียวกัน เพื่อคุยและโทรหากัน",
		waitingPartner: "รออีกฝ่ายเข้าร่วม",
		partnerOnline: "อยู่ด้วยกันแล้ว",
		sendingAs: "ส่งในนาม",
		switchHint: "แตะชื่อเพื่อส่งข้อความในนามคุณหรือในนามอีกฝ่าย — ใช้โทรศัพท์เครื่องเดียวด้วยกันได้",
		onboardingTitle: "เราทั้งคู่",
		onboardingSub: "ใส่ชื่อแล้วเริ่มพื้นที่ที่เป็นของเราสองคน",
		continue: "ต่อไป",
		start: "เริ่มต้น",
		pickLanguage: "ภาษา",
		whoAmI: "โทรศัพท์เครื่องนี้เป็นของ",
		iAmMe: "ฉัน",
		iAmPartner: "คนรัก",
		newNote: "บันทึกใหม่",
		download: "ดาวน์โหลด",
		close: "ปิด",
		english: "English",
		myanmar: "မြန်မာ",
		thai: "ไทย",
		colorPresets: "สีที่เลือกไว้",
		wallpaperHint: "เปลี่ยนพื้นหลังเป็นรูปที่คุณชอบได้",
		important: "สิ่งสำคัญ",
		fromMe: "จากฉัน",
		fromThem: "จากคนรัก",
		all: "ทั้งหมด",
		enterCode: "เข้าร่วมด้วยรหัสของอีกฝ่าย",
		applyCode: "เข้าร่วม",
		codeInvalid: "ใช้ตัวอักษรหรือตัวเลข 4–8 ตัว",
		previewCall: "กล้องเปิดอยู่ อีกฝ่ายจะปรากฏเมื่อเข้าร่วมด้วยรหัสคู่",
		noPeerCall: "สายจะดังบนเครื่องนี้จนกว่าอีกฝ่ายจะเข้า"
	}
};
function t(lang, id) {
	return strings[lang][id];
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium select-none transition-transform duration-150 ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70 focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:opacity-40 active:scale-[0.98]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg shadow-[0_1px_0_color-mix(in_oklab,black_20%,transparent)]",
			ghost: "bg-transparent text-fg hover:bg-fg/6",
			outline: "border border-border bg-transparent text-fg hover:bg-fg/6",
			surface: "bg-surface text-fg border border-border",
			danger: "bg-danger text-fg"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-lg px-4 text-sm",
			lg: "h-12 rounded-xl px-5 text-base",
			icon: "size-11 rounded-full",
			"icon-sm": "size-9 rounded-full"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-lg border border-border bg-surface px-3 text-base text-fg placeholder:text-subtle", "transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", className),
		...props
	});
}
function useBlobUrl(id) {
	const [url, setUrl] = (0, import_react.useState)();
	(0, import_react.useEffect)(() => {
		if (!id) {
			setUrl(void 0);
			return;
		}
		let live = true;
		blobUrl(id).then((u) => {
			if (live) setUrl(u);
		});
		return () => {
			live = false;
		};
	}, [id]);
	return url;
}
function PersonAvatar({ name, avatarId, className, ring }) {
	const url = useBlobUrl(avatarId);
	const initial = (name.trim()[0] || "?").toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("relative shrink-0 overflow-hidden rounded-full bg-surface text-accent", ring && "ring-2 ring-accent ring-offset-2 ring-offset-bg", className),
		children: url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: url,
			alt: "",
			className: "size-full object-cover"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid size-full place-items-center font-display text-[0.9em] font-medium",
			children: initial
		})
	});
}
function Onboarding() {
	const settings = useApp((s) => s.settings);
	const patch = useApp((s) => s.patchSettings);
	const setPerson = useApp((s) => s.setPerson);
	const setAvatar = useApp((s) => s.setAvatar);
	const lang = settings.lang;
	const [step, setStep] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/wallpaper.jpg",
				alt: "",
				className: "pointer-events-none absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-bg/72" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex w-full max-w-lg flex-1 flex-col px-6 pb-10 pt-[max(3rem,env(safe-area-inset-top))]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-10 flex items-center gap-2 text-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
						className: "size-4 fill-accent text-accent",
						strokeWidth: 1.5
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm tracking-wide",
						children: t(lang, "appName")
					})]
				}), step === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-1 flex-col",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-medium leading-tight text-fg",
							children: t(lang, "onboardingTitle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-sm text-muted",
							children: t(lang, "onboardingSub")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-10 text-sm font-medium text-subtle",
							children: t(lang, "pickLanguage")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 grid gap-2",
							children: [
								"my",
								"en",
								"th"
							].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => patch({ lang: code }),
								className: cn("flex h-14 items-center justify-between rounded-xl border px-4 text-left transition-colors duration-150", lang === code ? "border-accent bg-accent/15 text-fg" : "border-border bg-surface/80 text-muted"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-base font-medium",
									children: code === "my" ? t(lang, "myanmar") : code === "en" ? t(lang, "english") : t(lang, "thai")
								}), lang === code ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-accent" }) : null]
							}, code))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-auto pt-10",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "w-full",
								size: "lg",
								onClick: () => setStep(1),
								children: t(lang, "continue")
							})
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NamesStep, {
					lang,
					meName: settings.me.name,
					partnerName: settings.partner.name,
					meAvatar: settings.me.avatarId,
					partnerAvatar: settings.partner.avatarId,
					onMe: (v) => setPerson("me", { name: v }),
					onPartner: (v) => setPerson("partner", { name: v }),
					onMePhoto: (f) => void setAvatar("me", f),
					onPartnerPhoto: (f) => void setAvatar("partner", f),
					onBack: () => setStep(0),
					onStart: () => patch({
						onboarded: true,
						me: {
							...settings.me,
							name: settings.me.name.trim() || defaultMe(lang)
						},
						partner: {
							...settings.partner,
							name: settings.partner.name.trim() || defaultPartner(lang)
						}
					})
				})]
			})
		]
	});
}
function defaultMe(lang) {
	return lang === "my" ? "ကိုယ်" : lang === "th" ? "ฉัน" : "Me";
}
function defaultPartner(lang) {
	return lang === "my" ? "ချစ်သူ" : lang === "th" ? "คนรัก" : "You";
}
function NamesStep({ lang, meName, partnerName, meAvatar, partnerAvatar, onMe, onPartner, onMePhoto, onPartnerPhoto, onBack, onStart }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl font-medium leading-tight",
				children: t(lang, "onboardingTitle")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: t(lang, "onboardingSub")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameField, {
					lang,
					label: t(lang, "myName"),
					name: meName,
					avatarId: meAvatar,
					onName: onMe,
					onPhoto: onMePhoto
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NameField, {
					lang,
					label: t(lang, "partnerName"),
					name: partnerName,
					avatarId: partnerAvatar,
					onName: onPartner,
					onPhoto: onPartnerPhoto
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-auto flex gap-2 pt-10",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: "flex-1",
					onClick: onBack,
					children: t(lang, "cancel")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "flex-[2]",
					size: "lg",
					onClick: onStart,
					children: t(lang, "start")
				})]
			})
		]
	});
}
function NameField({ lang, label, name, avatarId, onName, onPhoto }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-medium text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "relative cursor-pointer",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
					name: name || label,
					avatarId,
					className: "size-14"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "file",
					accept: "image/*",
					className: "sr-only",
					"aria-label": t(lang, "myPhoto"),
					onChange: (e) => {
						const f = e.target.files?.[0];
						if (f) onPhoto(f);
						e.target.value = "";
					}
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				onChange: (e) => onName(e.target.value),
				className: "flex-1"
			})]
		})]
	});
}
function BlobImage({ id, alt, className }) {
	const url = useBlobUrl(id);
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("bg-surface", className),
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: url,
		alt,
		className
	});
}
function BlobVideo({ id, className, controls = true, muted, autoPlay }) {
	const url = useBlobUrl(id);
	if (!url) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("bg-surface", className),
		"aria-hidden": true
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
		src: url,
		className,
		controls,
		playsInline: true,
		muted,
		autoPlay
	});
}
var FAST_POLL_MS = 400;
var IDLE_POLL_MS = 2e3;
var PING_INTERVAL_MS = 2e3;
var STALL_MS = 1e4;
var MAX_RECOVERY_ATTEMPTS = 3;
var SIGNAL_RETRY_DELAYS_MS = [250, 750];
function defaultIceServers() {
	return [{ urls: ["stun:stun.l.google.com:19302", "stun:stun.cloudflare.com:3478"] }];
}
var P2PRoom = class {
	opts;
	peers = /* @__PURE__ */ new Map();
	/** Per-remote-peer signal delivery chains (order-preserving). */
	signalQueues = /* @__PURE__ */ new Map();
	cursor = 0;
	pollTimer = null;
	pingTimer = null;
	closed = false;
	everPolled = false;
	lastPeersFingerprint = "";
	localStream = null;
	constructor(opts) {
		this.opts = opts;
	}
	/**
	* The first poll IS the join: it registers this peer and returns the
	* roster. A failed first poll (cold DB, offline tab) must not strand the
	* room: the loop and timers start regardless and the next poll retries.
	*/
	async join() {
		try {
			await this.pollOnce();
		} catch {}
		if (this.closed) return;
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
		this.pingTimer = setInterval(() => {
			this.pingAll();
			this.watchdog();
		}, PING_INTERVAL_MS);
	}
	close() {
		this.closed = true;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		if (this.pingTimer) clearInterval(this.pingTimer);
		for (const slot of this.peers.values()) slot.pc.close();
		this.peers.clear();
		fetch("/api/rtc", {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				op: "leave",
				room: this.opts.room,
				peer: this.opts.selfId
			}),
			keepalive: true
		}).catch(() => {});
	}
	/** Send on the unreliable game-state channel (drops stale packets). */
	broadcast(data) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		for (const slot of this.peers.values()) if (slot.state?.readyState === "open") slot.state.send(wire);
	}
	/** Send reliably (ordered) to one peer, or to all when peerId is omitted. */
	send(data, peerId) {
		const wire = JSON.stringify({
			t: "d",
			d: data
		});
		const targets = peerId ? [this.peers.get(peerId)] : [...this.peers.values()];
		for (const slot of targets) if (slot?.reliable?.readyState === "open") slot.reliable.send(wire);
	}
	peerList() {
		return [...this.peers.values()].map((s) => ({ ...s.info }));
	}
	/**
	* Publish (or clear) local camera/mic onto every connected peer.
	* Adding tracks retriggers negotiation so an in-progress mesh picks them up.
	*/
	setLocalStream(stream) {
		if (this.localStream) {
			for (const slot of this.peers.values()) for (const sender of slot.pc.getSenders()) if (sender.track && this.localStream.getTracks().includes(sender.track)) slot.pc.removeTrack(sender);
		}
		this.localStream = stream;
		if (!stream) return;
		for (const slot of this.peers.values()) for (const track of stream.getTracks()) slot.pc.addTrack(track, stream);
	}
	/** Mute / swap camera without tearing the call down. */
	replaceTrack(kind, track) {
		for (const slot of this.peers.values()) {
			const sender = slot.pc.getSenders().find((s) => s.track?.kind === kind);
			if (sender) sender.replaceTrack(track);
		}
	}
	schedulePoll(delay) {
		if (this.closed) return;
		if (this.pollTimer) clearTimeout(this.pollTimer);
		this.pollTimer = setTimeout(() => void this.poll(), delay);
	}
	anyPairConnecting() {
		for (const s of this.peers.values()) {
			if (s.terminal) continue;
			if (s.info.connectionState !== "connected") return true;
		}
		return false;
	}
	async pollOnce() {
		const params = new URLSearchParams({
			room: this.opts.room,
			peer: this.opts.selfId,
			name: this.opts.name ?? "",
			since: String(this.cursor)
		});
		const res = await fetch(`/api/rtc?${params}`);
		if (this.closed) return;
		if (!res.ok) throw new Error(`signaling poll failed: ${res.status}`);
		const body = await res.json();
		if (this.closed) return;
		if (!this.everPolled) {
			this.everPolled = true;
			this.opts.onConnected?.();
		}
		this.reconcileRoster(body.peers);
		const roster = new Set(body.peers.map((p) => p.id));
		for (const sig of body.signals) {
			this.cursor = Math.max(this.cursor, sig.id);
			await this.onSignal(sig.from, sig.kind, sig.payload, roster);
			if (this.closed) return;
		}
	}
	async poll() {
		if (this.closed) return;
		try {
			await this.pollOnce();
		} catch {}
		this.schedulePoll(this.anyPairConnecting() ? FAST_POLL_MS : IDLE_POLL_MS);
	}
	reconcileRoster(peers) {
		const alive = new Set(peers.map((p) => p.id));
		for (const p of peers) {
			if (p.id === this.opts.selfId) continue;
			const existing = this.peers.get(p.id);
			if (existing) existing.info.name = p.name;
			else this.connectTo(p.id, p.name, this.opts.selfId > p.id);
		}
		for (const [id, slot] of this.peers) if (!alive.has(id)) {
			slot.pc.close();
			this.peers.delete(id);
		}
		this.emitPeers();
	}
	connectTo(peerId, name, initiator) {
		if (this.closed) return null;
		const pc = new RTCPeerConnection({ iceServers: this.opts.iceServers ?? defaultIceServers() });
		const slot = {
			pc,
			makingOffer: false,
			ignoreOffer: false,
			pendingCandidates: [],
			lastProgressAt: Date.now(),
			recoveryAttempts: 0,
			info: {
				id: peerId,
				name,
				connectionState: pc.connectionState,
				candidateType: null,
				rttMs: null
			}
		};
		this.peers.set(peerId, slot);
		pc.onicecandidate = (e) => {
			if (e.candidate) this.sendSignal(peerId, "ice", e.candidate.toJSON());
		};
		pc.onconnectionstatechange = () => {
			slot.info.connectionState = pc.connectionState;
			if (pc.connectionState === "connecting" || pc.connectionState === "connected") slot.lastProgressAt = Date.now();
			if (pc.connectionState === "connected") {
				slot.recoveryAttempts = 0;
				slot.terminal = false;
				this.readCandidateType(slot);
			}
			this.emitPeers();
			if (pc.connectionState === "failed") pc.restartIce();
			if (pc.connectionState === "failed" || pc.connectionState === "disconnected") this.schedulePoll(FAST_POLL_MS);
		};
		pc.onnegotiationneeded = async () => {
			try {
				slot.makingOffer = true;
				await pc.setLocalDescription();
				await this.sendSignal(peerId, "offer", pc.localDescription.toJSON());
			} catch {} finally {
				slot.makingOffer = false;
			}
		};
		pc.ondatachannel = (e) => this.attachChannel(slot, e.channel);
		pc.ontrack = (ev) => this.opts.onTrack?.(peerId, ev);
		if (this.localStream) for (const track of this.localStream.getTracks()) pc.addTrack(track, this.localStream);
		if (initiator) {
			this.attachChannel(slot, pc.createDataChannel("state", {
				ordered: false,
				maxRetransmits: 0
			}));
			this.attachChannel(slot, pc.createDataChannel("reliable", { ordered: true }));
		}
		return slot;
	}
	attachChannel(slot, channel) {
		if (channel.label === "state") slot.state = channel;
		else slot.reliable = channel;
		channel.onopen = () => {
			slot.lastProgressAt = Date.now();
		};
		channel.onmessage = (e) => {
			let msg;
			try {
				msg = JSON.parse(e.data);
			} catch {
				return;
			}
			if (msg.t === "ping") {
				if (slot.state?.readyState === "open") slot.state.send(JSON.stringify({ t: "pong" }));
			} else if (msg.t === "pong") {
				if (slot.pingSentAt) {
					slot.info.rttMs = Math.round(performance.now() - slot.pingSentAt);
					slot.pingSentAt = void 0;
					this.emitPeers();
				}
			} else this.opts.onMessage?.(slot.info.id, msg.d, channel.label === "state" ? "state" : "reliable");
		};
	}
	/** Apply buffered ICE candidates once a remote description is in place. */
	async flushPendingCandidates(slot) {
		while (slot.pendingCandidates.length > 0) {
			const candidate = slot.pendingCandidates.shift();
			try {
				await slot.pc.addIceCandidate(candidate);
			} catch (err) {
				if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
			}
			if (this.closed) return;
		}
	}
	async onSignal(from, kind, payload, roster) {
		if (this.closed) return;
		let slot = this.peers.get(from);
		if (!slot) {
			if (!roster.has(from)) return;
			const created = this.connectTo(from, "", false);
			if (!created) return;
			slot = created;
		}
		const polite = this.opts.selfId < from;
		try {
			if (kind === "offer" || kind === "answer") {
				const description = payload;
				const collision = kind === "offer" && (slot.makingOffer || slot.pc.signalingState !== "stable");
				slot.ignoreOffer = !polite && collision;
				if (slot.ignoreOffer) return;
				try {
					await slot.pc.setRemoteDescription(description);
				} catch (err) {
					if (kind !== "offer" || slot.recreatedForOffer) throw err;
					const attempts = slot.recoveryAttempts;
					const name = slot.info.name;
					slot.pc.close();
					this.peers.delete(from);
					const fresh = this.connectTo(from, name, false);
					if (!fresh) return;
					fresh.recoveryAttempts = attempts;
					fresh.recreatedForOffer = true;
					slot = fresh;
					await slot.pc.setRemoteDescription(description);
				}
				if (this.closed) return;
				await this.flushPendingCandidates(slot);
				if (this.closed) return;
				if (kind === "offer") {
					await slot.pc.setLocalDescription();
					if (this.closed) return;
					await this.sendSignal(from, "answer", slot.pc.localDescription.toJSON());
				}
			} else if (kind === "ice") {
				const candidate = payload;
				if (!slot.pc.remoteDescription) {
					slot.pendingCandidates.push(candidate);
					return;
				}
				try {
					await slot.pc.addIceCandidate(candidate);
				} catch (err) {
					if (!slot.ignoreOffer) console.warn("[p2p] addIceCandidate failed:", err);
				}
			}
		} catch {}
	}
	/**
	* Signals are serialized per remote peer (a candidate must never overtake
	* its SDP into the DB) and retried on failure with short backoff.
	*/
	sendSignal(to, kind, payload) {
		const next = (this.signalQueues.get(to) ?? Promise.resolve()).then(() => this.postSignal(to, kind, payload));
		this.signalQueues.set(to, next.catch(() => {}));
		return next;
	}
	async postSignal(to, kind, payload) {
		for (let attempt = 0;; attempt++) {
			if (this.closed) return;
			try {
				const res = await fetch("/api/rtc", {
					method: "POST",
					headers: { "content-type": "application/json" },
					body: JSON.stringify({
						op: "signal",
						room: this.opts.room,
						from: this.opts.selfId,
						to,
						kind,
						payload
					})
				});
				if (res.ok) return;
				throw new Error(`signal POST failed: ${res.status}`);
			} catch (err) {
				if (attempt >= SIGNAL_RETRY_DELAYS_MS.length) {
					console.warn(`[p2p] signal ${kind} to ${to} failed after retries`, err);
					return;
				}
				await new Promise((r) => setTimeout(r, SIGNAL_RETRY_DELAYS_MS[attempt]));
			}
		}
	}
	pingAll() {
		const wire = JSON.stringify({ t: "ping" });
		for (const slot of this.peers.values()) {
			if (slot.state?.readyState !== "open") continue;
			const stale = slot.pingSentAt !== void 0 && performance.now() - slot.pingSentAt > 2 * PING_INTERVAL_MS;
			if (slot.pingSentAt === void 0 || stale) {
				slot.pingSentAt = performance.now();
				slot.state.send(wire);
			}
		}
	}
	/**
	* Stuck-pair recovery, piggybacked on the ping interval. A pair that has
	* made no progress for STALL_MS gets rebuilt by the dialer with a FRESH
	* RTCPeerConnection (new DTLS identity — fixes the suspend/resume
	* fingerprint wedge). After MAX_RECOVERY_ATTEMPTS the pair is terminal:
	* visible to the app as its last connectionState, ignored by fast-poll.
	*/
	watchdog() {
		if (this.closed) return;
		const now = Date.now();
		for (const [peerId, slot] of this.peers) {
			const live = slot.pc.connectionState;
			if (live !== slot.info.connectionState) {
				slot.info.connectionState = live;
				if (live === "connecting" || live === "connected") slot.lastProgressAt = now;
				this.emitPeers();
			}
			if (slot.terminal || live === "connected") continue;
			if (now - slot.lastProgressAt <= STALL_MS) continue;
			if (slot.recoveryAttempts >= MAX_RECOVERY_ATTEMPTS) {
				slot.terminal = true;
				this.emitPeers();
				continue;
			}
			slot.recoveryAttempts += 1;
			slot.lastProgressAt = now;
			if (this.opts.selfId > peerId) {
				const { name } = slot.info;
				const attempts = slot.recoveryAttempts;
				slot.pc.close();
				this.peers.delete(peerId);
				const fresh = this.connectTo(peerId, name, true);
				if (fresh) fresh.recoveryAttempts = attempts;
				this.schedulePoll(FAST_POLL_MS);
			}
		}
	}
	async readCandidateType(slot) {
		try {
			const stats = await slot.pc.getStats();
			let selected;
			stats.forEach((s) => {
				if (s.type === "candidate-pair" && s.nominated) selected = s;
			});
			const localId = selected?.localCandidateId;
			if (localId) {
				const local = stats.get(localId);
				slot.info.candidateType = local?.candidateType ?? null;
				this.emitPeers();
			}
		} catch {}
	}
	emitPeers() {
		const list = this.peerList();
		const fingerprint = JSON.stringify(list.map((p) => [
			p.id,
			p.name,
			p.connectionState,
			p.candidateType,
			p.rttMs
		]));
		if (fingerprint === this.lastPeersFingerprint) return;
		this.lastPeersFingerprint = fingerprint;
		this.opts.onPeersChanged?.(list);
	}
};
function defaultRoom() {
	if (typeof window === "undefined") return "room-ssr";
	return `room-${window.location.hostname.split(".")[0]}`.slice(0, 64);
}
function useP2PRoom(options = {}) {
	const enabled = options.enabled !== false;
	const [selfId] = (0, import_react.useState)(() => `p-${Math.random().toString(36).slice(2, 10)}`);
	const [room] = (0, import_react.useState)(() => options.room ?? defaultRoom());
	const [name] = (0, import_react.useState)(() => options.name ?? selfId);
	const [peers, setPeers] = (0, import_react.useState)([]);
	const [joined, setJoined] = (0, import_react.useState)(false);
	const roomRef = (0, import_react.useRef)(null);
	const listeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const trackListeners = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		const p2p = new P2PRoom({
			room,
			selfId,
			name,
			onPeersChanged: setPeers,
			onMessage: (from, data, channel) => {
				for (const fn of listeners.current) fn(from, data, channel);
			},
			onConnected: () => setJoined(true),
			onTrack: (from, event) => {
				for (const fn of trackListeners.current) fn(from, event);
			}
		});
		roomRef.current = p2p;
		p2p.join();
		return () => {
			roomRef.current = null;
			p2p.close();
		};
	}, [
		room,
		selfId,
		name,
		enabled
	]);
	return {
		selfId,
		room,
		peers,
		joined,
		broadcast: (0, import_react.useCallback)((data) => roomRef.current?.broadcast(data), []),
		send: (0, import_react.useCallback)((data, peerId) => roomRef.current?.send(data, peerId), []),
		onMessage: (0, import_react.useCallback)((fn) => {
			listeners.current.add(fn);
			return () => {
				listeners.current.delete(fn);
			};
		}, []),
		setLocalStream: (0, import_react.useCallback)((stream) => {
			roomRef.current?.setLocalStream(stream);
		}, []),
		replaceTrack: (0, import_react.useCallback)((kind, track) => {
			roomRef.current?.replaceTrack(kind, track);
		}, []),
		onTrack: (0, import_react.useCallback)((fn) => {
			trackListeners.current.add(fn);
			return () => {
				trackListeners.current.delete(fn);
			};
		}, [])
	};
}
var LinkCtx = (0, import_react.createContext)(null);
function useLink() {
	return (0, import_react.useContext)(LinkCtx);
}
function LinkProvider({ children }) {
	const onboarded = useApp((s) => s.settings.onboarded);
	const code = useApp((s) => s.settings.coupleCode);
	const name = useApp((s) => s.settings.me.name);
	const room = `us-${code}`.slice(0, 64);
	if (!onboarded || !code) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkInner, {
		room,
		name: name || "me",
		children
	}, room);
}
function LinkInner({ room, name, children }) {
	const p2p = useP2PRoom({
		room,
		name,
		enabled: true
	});
	const ingest = useApp((s) => s.ingestRemoteMessage);
	const applyNotes = useApp((s) => s.applyRemoteNotes);
	const applyAlbum = useApp((s) => s.applyRemoteAlbum);
	const receiveCall = useApp((s) => s.receiveCall);
	const acceptCall = useApp((s) => s.acceptCall);
	const endCall = useApp((s) => s.endCall);
	const callPhase = useApp((s) => s.call.phase);
	const lang = useApp((s) => s.settings.lang);
	const role = useApp((s) => s.settings.activeRole);
	const chunks = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const callPhaseRef = (0, import_react.useRef)(callPhase);
	callPhaseRef.current = callPhase;
	(0, import_react.useEffect)(() => {
		return p2p.onMessage((_from, data) => {
			const msg = data;
			if (!msg || typeof msg !== "object" || !("t" in msg)) return;
			if (msg.t === "chat") ingest(msg.msg, msg.media);
			else if (msg.t === "media-meta") chunks.current.set(msg.id, {
				parts: Array(msg.n).fill(""),
				n: msg.n,
				msg: msg.msg
			});
			else if (msg.t === "media-chunk") {
				const buf = chunks.current.get(msg.id);
				if (!buf) return;
				buf.parts[msg.i] = msg.chunk;
				if (buf.parts.every(Boolean)) {
					const dataUrl = buf.parts.join("");
					chunks.current.delete(msg.id);
					ingest(buf.msg, dataUrl);
				}
			} else if (msg.t === "note-sync") applyNotes(msg.notes);
			else if (msg.t === "album") applyAlbum(msg.item, msg.media);
			else if (msg.t === "call") {
				if (msg.action === "invite" && callPhaseRef.current === "idle") receiveCall(msg.kind);
				if (msg.action === "accept") acceptCall();
				if (msg.action === "decline" || msg.action === "end") endCall();
			} else if (msg.t === "hello") {}
		});
	}, [
		p2p,
		ingest,
		applyNotes,
		applyAlbum,
		receiveCall,
		acceptCall,
		endCall
	]);
	(0, import_react.useEffect)(() => {
		if (!p2p.peers.some((p) => p.connectionState === "connected")) return;
		p2p.send({
			t: "hello",
			role,
			name
		});
		p2p.send({
			t: "note-sync",
			notes: useApp.getState().notes
		});
	}, [
		p2p,
		p2p.peers,
		role,
		name
	]);
	(0, import_react.useEffect)(() => {
		if (p2p.peers.some((p) => p.connectionState === "connected")) toast.success(t(lang, "partnerOnline"));
	}, [p2p.peers.some((p) => p.connectionState === "connected")]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkCtx.Provider, {
		value: p2p,
		children
	});
}
async function sendChatOverLink(p2p, msg) {
	if (!p2p || p2p.peers.every((p) => p.connectionState !== "connected")) return;
	let media;
	if (msg.mediaId) {
		const blob = await blobGet(msg.mediaId);
		if (blob && blob.size < 24e5) media = await blobToDataUrl(blob);
	}
	if (media && media.length > 14e3) {
		const parts = chunkDataUrl(media);
		p2p.send({
			t: "media-meta",
			id: msg.id,
			mime: dataUrlToBlob(media).type,
			n: parts.length,
			msg
		});
		parts.forEach((chunk, i) => p2p.send({
			t: "media-chunk",
			id: msg.id,
			i,
			chunk
		}));
		return;
	}
	p2p.send({
		t: "chat",
		msg,
		media
	});
}
async function sendAlbumOverLink(p2p, item) {
	if (!p2p || p2p.peers.every((p) => p.connectionState !== "connected")) return;
	const blob = await blobGet(item.blobId);
	if (!blob || blob.size > 24e5) return;
	const media = await blobToDataUrl(blob);
	p2p.send({
		t: "album",
		item,
		media
	});
}
function sendNotesOverLink(p2p, notes) {
	if (!p2p) return;
	p2p.send({
		t: "note-sync",
		notes
	});
}
function sendCallSignal(p2p, action, kind) {
	p2p?.send({
		t: "call",
		action,
		kind
	});
}
function ChatView() {
	const settings = useApp((s) => s.settings);
	const messages = useApp((s) => s.messages);
	const sendMessage = useApp((s) => s.sendMessage);
	const saveMedia = useApp((s) => s.saveMessageMedia);
	const startCall = useApp((s) => s.startCall);
	const patch = useApp((s) => s.patchSettings);
	const lang = settings.lang;
	const p2p = useLink();
	const [draft, setDraft] = (0, import_react.useState)("");
	const scroller = (0, import_react.useRef)(null);
	const photoRef = (0, import_react.useRef)(null);
	const videoRef = (0, import_react.useRef)(null);
	const online = p2p?.peers.some((p) => p.connectionState === "connected") ?? false;
	(0, import_react.useEffect)(() => {
		const el = scroller.current;
		if (el) el.scrollTop = el.scrollHeight;
	}, [messages.length]);
	async function submit(e, media) {
		e?.preventDefault();
		const text = draft;
		if (!text.trim() && !media) return;
		setDraft("");
		const msg = await sendMessage(text, media);
		await sendChatOverLink(p2p, msg);
	}
	function beginCall(kind) {
		startCall(kind);
		sendCallSignal(p2p, "invite", kind);
	}
	const them = settings.activeRole === "me" ? settings.partner : settings.me;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 border-b border-border px-4 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
						name: them.name,
						avatarId: them.avatarId,
						className: "size-10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-medium leading-tight",
							children: them.name || t(lang, "partnerName")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-1.5 text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-1.5 rounded-full", online ? "bg-accent" : "bg-subtle") }), online ? t(lang, "partnerOnline") : t(lang, "waitingPartner")]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "call"),
						onClick: () => beginCall("audio"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "videoCall"),
						onClick: () => beginCall("video"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-5" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-b border-border px-4 py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-subtle",
						children: t(lang, "sendingAs")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleChip, {
						active: settings.activeRole === "me",
						name: settings.me.name || t(lang, "iAmMe"),
						avatarId: settings.me.avatarId,
						onClick: () => patch({ activeRole: "me" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleChip, {
						active: settings.activeRole === "partner",
						name: settings.partner.name || t(lang, "iAmPartner"),
						avatarId: settings.partner.avatarId,
						onClick: () => patch({ activeRole: "partner" })
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scroller,
				className: "min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4",
				children: messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-16 text-center text-sm text-muted",
					children: t(lang, "emptyChat")
				}) : messages.map((m, i) => {
					const showDay = i === 0 || formatDay(m.createdAt, lang) !== formatDay(messages[i - 1].createdAt, lang);
					const mine = m.from === settings.activeRole;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [showDay ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-center text-xs text-subtle",
						children: formatDay(m.createdAt, lang)
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bubble, {
						msg: m,
						mine,
						lang,
						time: formatTime(m.createdAt, lang),
						onSave: () => void saveMedia(m.id)
					})] }, m.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: (e) => void submit(e),
				className: "flex items-end gap-2 border-t border-border px-3 py-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: photoRef,
						type: "file",
						accept: "image/*",
						className: "sr-only",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (f) submit(void 0, {
								blob: f,
								kind: "image"
							});
							e.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: videoRef,
						type: "file",
						accept: "video/*",
						className: "sr-only",
						onChange: (e) => {
							const f = e.target.files?.[0];
							if (f) submit(void 0, {
								blob: f,
								kind: "video"
							});
							e.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "attachPhoto"),
						onClick: () => photoRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "attachVideo"),
						onClick: () => videoRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: draft,
						onChange: (e) => setDraft(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter" && !e.shiftKey) {
								e.preventDefault();
								submit();
							}
						},
						rows: 1,
						placeholder: t(lang, "typeMessage"),
						className: "max-h-28 min-h-11 flex-1 resize-none rounded-lg border border-border bg-surface px-3 py-2.5 text-base text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "icon",
						"aria-label": t(lang, "send"),
						disabled: !draft.trim(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "size-4" })
					})
				]
			})
		]
	});
}
function RoleChip({ active, name, avatarId, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick,
		className: cn("flex items-center gap-1.5 rounded-full py-1 pr-2.5 pl-1 text-xs transition-colors duration-150", active ? "bg-accent text-accent-fg" : "bg-surface text-muted"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
			name,
			avatarId,
			className: "size-5"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "max-w-20 truncate",
			children: name
		})]
	});
}
function Bubble({ msg, mine, lang, time, onSave }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex", mine ? "justify-end" : "justify-start"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("max-w-[78%] overflow-hidden rounded-2xl", mine ? "rounded-br-sm bg-accent text-accent-fg" : "rounded-bl-sm bg-surface text-fg"),
			children: [
				msg.mediaKind === "image" && msg.mediaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobImage, {
					id: msg.mediaId,
					alt: "",
					className: "max-h-72 w-full object-cover"
				}) : null,
				msg.mediaKind === "video" && msg.mediaId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobVideo, {
					id: msg.mediaId,
					className: "max-h-72 w-full"
				}) : null,
				msg.text ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-3 py-2 text-[0.95rem] leading-snug",
					children: msg.text
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: cn("flex items-center justify-end gap-2 px-3 pb-1.5", msg.text ? "" : "pt-1.5"),
					children: [
						msg.mediaId && !msg.saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onSave,
							className: cn("text-[11px] underline-offset-2 hover:underline", mine ? "text-accent-fg/80" : "text-muted"),
							children: msg.mediaKind === "video" ? t(lang, "saveToVideos") : t(lang, "saveToPhotos")
						}) : null,
						msg.saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[11px]", mine ? "text-accent-fg/70" : "text-subtle"),
							children: t(lang, "saved")
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("text-[11px] tabular-nums", mine ? "text-accent-fg/70" : "text-subtle"),
							children: time
						})
					]
				})
			]
		})
	});
}
function PhotosView() {
	const photos = useApp((s) => s.photos);
	const settings = useApp((s) => s.settings);
	const addAlbum = useApp((s) => s.addAlbum);
	const lang = settings.lang;
	const p2p = useLink();
	const fileRef = (0, import_react.useRef)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const list = photos.filter((p) => filter === "all" ? true : p.from === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-medium",
						children: t(lang, "photos")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(lang, "emptyPhotos")
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						"aria-label": t(lang, "addPhoto"),
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "image/*",
						className: "sr-only",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							e.target.value = "";
							if (!f) return;
							const item = await addAlbum("image", f, "", settings.activeRole);
							await sendAlbumOverLink(p2p, item);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 px-4 pb-3",
				children: [
					"all",
					"me",
					"partner"
				].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(id),
					className: cn("h-8 rounded-full px-3 text-xs font-medium", filter === id ? "bg-accent text-accent-fg" : "bg-surface text-muted"),
					children: id === "all" ? t(lang, "all") : id === "me" ? t(lang, "fromMe") : t(lang, "fromThem")
				}, id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyPhotos, { lang }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
					children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(p),
						className: "aspect-square overflow-hidden rounded-xl bg-surface",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobImage, {
							id: p.blobId,
							alt: p.caption || t(lang, "photos"),
							className: "size-full object-cover"
						})
					}, p.id))
				})
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				item: open,
				kind: "photos",
				onClose: () => setOpen(null)
			}) : null
		]
	});
}
function EmptyPhotos({ lang }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative mx-4 mt-2 flex flex-1 flex-col overflow-hidden rounded-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/empty-photos.jpg",
				alt: "",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/55" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative m-auto max-w-xs px-6 text-center text-sm text-fg",
				children: t(lang, "emptyPhotos")
			})
		]
	});
}
function Lightbox({ item, kind, onClose }) {
	const lang = useApp((s) => s.settings.lang);
	const updateCaption = useApp((s) => s.updateCaption);
	const removeAlbum = useApp((s) => s.removeAlbum);
	const [caption, setCaption] = (0, import_react.useState)(item.caption);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex flex-col bg-bg/95",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between px-3 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-sm",
					"aria-label": t(lang, "close"),
					onClick: onClose,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "download"),
						onClick: async () => {
							const blob = await blobGet(item.blobId);
							if (blob) downloadBlob(blob, item.kind === "video" ? "memory.mp4" : "memory.jpg");
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium",
							children: t(lang, "download")
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-sm",
						"aria-label": t(lang, "delete"),
						onClick: () => {
							removeAlbum(kind, item.id);
							onClose();
						},
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-0 flex-1 items-center justify-center px-3",
				children: item.kind === "image" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobImage, {
					id: item.blobId,
					alt: item.caption,
					className: "max-h-full max-w-full rounded-xl object-contain"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobVideo, {
					id: item.blobId,
					className: "max-h-full max-w-full rounded-xl"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex gap-2 px-4 py-4 pb-[max(1rem,env(safe-area-inset-bottom))]",
				onSubmit: (e) => {
					e.preventDefault();
					updateCaption(kind, item.id, caption);
					onClose();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: caption,
					onChange: (e) => setCaption(e.target.value),
					placeholder: t(lang, "caption")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: t(lang, "save")
				})]
			})
		]
	});
}
function VideosView() {
	const videos = useApp((s) => s.videos);
	const settings = useApp((s) => s.settings);
	const addAlbum = useApp((s) => s.addAlbum);
	const lang = settings.lang;
	const p2p = useLink();
	const fileRef = (0, import_react.useRef)(null);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const list = videos.filter((p) => filter === "all" ? true : p.from === filter);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-2xl font-medium",
						children: t(lang, "videos")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: t(lang, "emptyVideos")
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						"aria-label": t(lang, "addVideo"),
						onClick: () => fileRef.current?.click(),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "video/*",
						className: "sr-only",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							e.target.value = "";
							if (!f) return;
							const item = await addAlbum("video", f, "", settings.activeRole);
							await sendAlbumOverLink(p2p, item);
						}
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 px-4 pb-3",
				children: [
					"all",
					"me",
					"partner"
				].map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(id),
					className: cn("h-8 rounded-full px-3 text-xs font-medium", filter === id ? "bg-accent text-accent-fg" : "bg-surface text-muted"),
					children: id === "all" ? t(lang, "all") : id === "me" ? t(lang, "fromMe") : t(lang, "fromThem")
				}, id))
			}),
			list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-4 mt-2 flex flex-1 flex-col overflow-hidden rounded-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/empty-videos.jpg",
						alt: "",
						className: "absolute inset-0 size-full object-cover"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/55" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "relative m-auto max-w-xs px-6 text-center text-sm text-fg",
						children: t(lang, "emptyVideos")
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-3 pb-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-3",
					children: list.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setOpen(p),
						className: "overflow-hidden rounded-xl bg-surface text-left",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlobVideo, {
							id: p.blobId,
							className: "aspect-video w-full object-cover",
							controls: false,
							muted: true
						}), p.caption ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "px-3 py-2 text-sm text-muted",
							children: p.caption
						}) : null]
					}, p.id))
				})
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
				item: open,
				kind: "videos",
				onClose: () => setOpen(null)
			}) : null
		]
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-24 w-full rounded-lg border border-border bg-surface px-3 py-2.5 text-base text-fg placeholder:text-subtle", "transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70", className),
		...props
	});
}
function NotesView() {
	const notes = useApp((s) => s.notes);
	const lang = useApp((s) => s.settings.lang);
	const addNote = useApp((s) => s.addNote);
	const updateNote = useApp((s) => s.updateNote);
	const removeNote = useApp((s) => s.removeNote);
	const p2p = useLink();
	const [editing, setEditing] = (0, import_react.useState)(null);
	const sorted = [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);
	function persist() {
		sendNotesOverLink(p2p, useApp.getState().notes);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-2xl font-medium",
					children: t(lang, "notes")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: t(lang, "important")
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					"aria-label": t(lang, "addNote"),
					onClick: () => setEditing("new"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 space-y-2 overflow-y-auto px-4 pb-4",
				children: sorted.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "pt-16 text-center text-sm text-muted",
					children: t(lang, "emptyNotes")
				}) : sorted.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setEditing(n),
					className: "w-full rounded-xl border border-border bg-surface px-4 py-3 text-left",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-medium leading-snug",
									children: n.title || t(lang, "newNote")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 line-clamp-2 text-sm text-muted",
									children: n.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-subtle",
									children: formatDay(n.updatedAt, lang)
								})
							]
						}), n.pinned ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: "size-4 shrink-0 text-accent" }) : null]
					})
				}, n.id))
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NoteEditor, {
				note: editing === "new" ? null : editing,
				onClose: () => setEditing(null),
				onSave: (title, body) => {
					if (editing === "new") addNote(title, body);
					else updateNote(editing.id, {
						title,
						body
					});
					persist();
					setEditing(null);
				},
				onDelete: editing === "new" ? void 0 : () => {
					removeNote(editing.id);
					persist();
					setEditing(null);
				},
				onPin: editing === "new" ? void 0 : () => {
					updateNote(editing.id, { pinned: !editing.pinned });
					persist();
					setEditing({
						...editing,
						pinned: !editing.pinned
					});
				}
			}) : null
		]
	});
}
function NoteEditor({ note, onClose, onSave, onDelete, onPin }) {
	const lang = useApp((s) => s.settings.lang);
	const [title, setTitle] = (0, import_react.useState)(note?.title ?? "");
	const [body, setBody] = (0, import_react.useState)(note?.body ?? "");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-lg rounded-t-2xl border border-border bg-bg-elevated p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:rounded-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: note ? t(lang, "edit") : t(lang, "newNote")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1",
						children: [onPin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": t(lang, "pin"),
							onClick: onPin,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pin, { className: cn("size-4", note?.pinned && "text-accent") })
						}) : null, onDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							"aria-label": t(lang, "delete"),
							onClick: onDelete,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4 text-danger" })
						}) : null]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: t(lang, "title"),
					className: "mb-3"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: body,
					onChange: (e) => setBody(e.target.value),
					placeholder: t(lang, "body"),
					className: "min-h-40"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "flex-1",
						onClick: onClose,
						children: t(lang, "cancel")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "flex-[2]",
						onClick: () => onSave(title, body),
						children: t(lang, "save")
					})]
				})
			]
		})
	});
}
function SettingsView() {
	const settings = useApp((s) => s.settings);
	const patch = useApp((s) => s.patchSettings);
	const setPerson = useApp((s) => s.setPerson);
	const setAvatar = useApp((s) => s.setAvatar);
	const setWallpaper = useApp((s) => s.setWallpaper);
	const lang = settings.lang;
	const p2p = useLink();
	const wallpaperUrl = useBlobUrl(settings.wallpaperId);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [join, setJoin] = (0, import_react.useState)("");
	const online = p2p?.peers.some((p) => p.connectionState === "connected") ?? false;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-0 flex-1 overflow-y-auto px-4 py-4 pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-medium",
				children: t(lang, "settings")
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: t(lang, "language"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-3 gap-2",
					children: [
						"my",
						"en",
						"th"
					].map((code) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ lang: code }),
						className: cn("h-11 rounded-lg border text-sm font-medium", lang === code ? "border-accent bg-accent/15 text-fg" : "border-border bg-surface text-muted"),
						children: code === "my" ? t(lang, "myanmar") : code === "en" ? t(lang, "english") : t(lang, "thai")
					}, code))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: t(lang, "whoAmI"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ activeRole: "me" }),
						className: cn("h-11 rounded-lg border text-sm font-medium", settings.activeRole === "me" ? "border-accent bg-accent/15" : "border-border bg-surface text-muted"),
						children: t(lang, "iAmMe")
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => patch({ activeRole: "partner" }),
						className: cn("h-11 rounded-lg border text-sm font-medium", settings.activeRole === "partner" ? "border-accent bg-accent/15" : "border-border bg-surface text-muted"),
						children: t(lang, "iAmPartner")
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-subtle",
					children: t(lang, "switchHint")
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: t(lang, "myName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
					name: settings.me.name,
					avatarId: settings.me.avatarId,
					onName: (v) => setPerson("me", { name: v }),
					onPhoto: (f) => void setAvatar("me", f)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
				title: t(lang, "partnerName"),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
					name: settings.partner.name,
					avatarId: settings.partner.avatarId,
					onName: (v) => setPerson("partner", { name: v }),
					onPhoto: (f) => void setAvatar("partner", f)
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: t(lang, "coupleCode"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "flex-1 rounded-lg border border-border bg-surface px-3 py-2.5 font-display text-xl tracking-[0.3em]",
							children: settings.coupleCode
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: async () => {
								await navigator.clipboard.writeText(settings.coupleCode);
								setCopied(true);
								setTimeout(() => setCopied(false), 1600);
							},
							children: copied ? t(lang, "copied") : t(lang, "copyCode")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-subtle",
						children: t(lang, "shareHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: online ? t(lang, "partnerOnline") : t(lang, "waitingPartner")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-3 flex gap-2",
						onSubmit: (e) => {
							e.preventDefault();
							const next = join.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
							if (next.length < 4 || next.length > 8) return;
							patch({ coupleCode: next });
							setJoin("");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: join,
							onChange: (e) => setJoin(e.target.value.toUpperCase()),
							placeholder: t(lang, "enterCode"),
							maxLength: 8
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "outline",
							children: t(lang, "applyCode")
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: t(lang, "themeColor"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-3 text-xs text-subtle",
					children: t(lang, "colorPresets")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3",
					children: [ACCENT_PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": p.id,
						onClick: () => patch({ accent: p.hex }),
						className: "size-10 rounded-full ring-offset-2 ring-offset-bg",
						style: {
							background: p.hex,
							boxShadow: settings.accent === p.hex ? `0 0 0 2px var(--fg)` : "0 0 0 1px var(--border)"
						},
						children: settings.accent === p.hex ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mx-auto size-4 text-accent-fg" }) : null
					}, p.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
						className: "relative size-10 overflow-hidden rounded-full border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "color",
							value: settings.accent,
							"aria-label": t(lang, "themeColor"),
							className: "absolute inset-0 size-[150%] -translate-x-1/4 -translate-y-1/4 cursor-pointer",
							onChange: (e) => patch({ accent: e.target.value })
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
				title: t(lang, "background"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-3 text-xs text-subtle",
						children: t(lang, "wallpaperHint")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-xl",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: wallpaperUrl || "/wallpaper.jpg",
							alt: "",
							className: "h-36 w-full object-cover"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "inline-flex h-11 w-full items-center justify-center rounded-lg bg-accent text-sm font-medium text-accent-fg",
								children: t(lang, "changeBackground")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "file",
								accept: "image/*",
								className: "sr-only",
								onChange: (e) => {
									const f = e.target.files?.[0];
									if (f) setWallpaper(f);
									e.target.value = "";
								}
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							onClick: () => void setWallpaper(null),
							children: t(lang, "resetBackground")
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-4 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-2 block text-xs text-subtle",
							children: t(lang, "backgroundDim")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "range",
							min: .2,
							max: .85,
							step: .05,
							value: settings.wallpaperDim,
							onChange: (e) => patch({ wallpaperDim: Number(e.target.value) }),
							className: "w-full accent-[var(--accent)]"
						})]
					})
				]
			})
		]
	});
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mb-3 text-sm font-medium text-subtle",
			children: title
		}), children]
	});
}
function PersonRow({ name, avatarId, onName, onPhoto }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "cursor-pointer",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
				name,
				avatarId,
				className: "size-12"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				accept: "image/*",
				className: "sr-only",
				onChange: (e) => {
					const f = e.target.files?.[0];
					if (f) onPhoto(f);
					e.target.value = "";
				}
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			value: name,
			onChange: (e) => onName(e.target.value)
		})]
	});
}
function startRingtone() {
	const ctx = new (window.AudioContext || window.webkitAudioContext)();
	let stopped = false;
	let timer = 0;
	const ping = (freq, at, dur = .28) => {
		const osc = ctx.createOscillator();
		const g = ctx.createGain();
		osc.type = "sine";
		osc.frequency.value = freq;
		osc.connect(g);
		g.connect(ctx.destination);
		const t0 = ctx.currentTime + at;
		g.gain.setValueAtTime(1e-4, t0);
		g.gain.exponentialRampToValueAtTime(.07, t0 + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, t0 + dur);
		osc.start(t0);
		osc.stop(t0 + dur + .02);
	};
	const loop = () => {
		if (stopped) return;
		ping(523.25, 0);
		ping(659.25, .32);
		timer = window.setTimeout(loop, 1700);
	};
	ctx.resume();
	loop();
	return () => {
		stopped = true;
		window.clearTimeout(timer);
		ctx.close();
	};
}
function CallOverlay() {
	const call = useApp((s) => s.call);
	const settings = useApp((s) => s.settings);
	const acceptCall = useApp((s) => s.acceptCall);
	const endCall = useApp((s) => s.endCall);
	const p2p = useLink();
	const lang = settings.lang;
	const partner = settings.partner;
	const localRef = (0, import_react.useRef)(null);
	const remoteRef = (0, import_react.useRef)(null);
	const streamRef = (0, import_react.useRef)(null);
	const [muted, setMuted] = (0, import_react.useState)(false);
	const [camOff, setCamOff] = (0, import_react.useState)(false);
	const [now, setNow] = (0, import_react.useState)(Date.now());
	const [remoteOn, setRemoteOn] = (0, import_react.useState)(false);
	const active = call.phase !== "idle";
	const isVideo = call.kind === "video";
	(0, import_react.useEffect)(() => {
		if (!active) return;
		const id = window.setInterval(() => setNow(Date.now()), 500);
		return () => window.clearInterval(id);
	}, [active]);
	(0, import_react.useEffect)(() => {
		if (call.phase !== "incoming" && call.phase !== "outgoing") return;
		return startRingtone();
	}, [call.phase]);
	(0, import_react.useEffect)(() => {
		if (!p2p) return;
		return p2p.onTrack((_from, ev) => {
			const el = remoteRef.current;
			const stream = ev.streams[0] ?? new MediaStream([ev.track]);
			if (el) el.srcObject = stream;
			setRemoteOn(true);
		});
	}, [p2p]);
	async function acquire() {
		try {
			const stream = await navigator.mediaDevices.getUserMedia({
				audio: true,
				video: isVideo ? {
					facingMode: "user",
					width: { ideal: 1280 },
					height: { ideal: 720 }
				} : false
			});
			streamRef.current = stream;
			if (localRef.current) localRef.current.srcObject = stream;
			p2p?.setLocalStream(stream);
			return true;
		} catch {
			toast.error(isVideo ? t(lang, "cameraBlocked") : t(lang, "microphoneBlocked"));
			return false;
		}
	}
	(0, import_react.useEffect)(() => {
		if (call.phase === "outgoing") acquire();
	}, [call.phase, call.kind]);
	(0, import_react.useEffect)(() => {
		if (call.phase !== "idle") return;
		streamRef.current?.getTracks().forEach((tr) => tr.stop());
		streamRef.current = null;
		p2p?.setLocalStream(null);
		setRemoteOn(false);
		setMuted(false);
		setCamOff(false);
	}, [call.phase, p2p]);
	if (!active) return null;
	async function onAccept() {
		if (!await acquire()) return;
		sendCallSignal(p2p, "accept", call.kind);
		acceptCall();
	}
	function hangup(action) {
		streamRef.current?.getTracks().forEach((tr) => tr.stop());
		streamRef.current = null;
		p2p?.setLocalStream(null);
		sendCallSignal(p2p, action, call.kind);
		endCall();
		setRemoteOn(false);
	}
	function toggleMute() {
		const next = !muted;
		setMuted(next);
		streamRef.current?.getAudioTracks().forEach((tr) => {
			tr.enabled = !next;
		});
		const track = streamRef.current?.getAudioTracks()[0];
		p2p?.replaceTrack("audio", next ? null : track ?? null);
	}
	function toggleCam() {
		const next = !camOff;
		setCamOff(next);
		streamRef.current?.getVideoTracks().forEach((tr) => {
			tr.enabled = !next;
		});
		const track = streamRef.current?.getVideoTracks()[0];
		p2p?.replaceTrack("video", next ? null : track ?? null);
	}
	const status = call.phase === "incoming" ? t(lang, "incomingCall") : call.phase === "outgoing" ? t(lang, "outgoingCall") : call.startedAt ? formatDuration(now - call.startedAt) : t(lang, "connected");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex flex-col bg-bg text-fg",
		children: [
			isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: remoteRef,
				className: "absolute inset-0 size-full object-cover",
				autoPlay: true,
				playsInline: true
			}) : null,
			!remoteOn || !isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/wallpaper.jpg",
					alt: "",
					className: "size-full object-cover opacity-40"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-bg/60" })]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative flex flex-1 flex-col items-center justify-center px-6 pt-[max(2.5rem,env(safe-area-inset-top))]",
				children: !remoteOn || call.phase !== "active" || !isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonAvatar, {
						name: partner.name,
						avatarId: partner.avatarId,
						className: "size-28"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-5 font-display text-3xl font-medium",
						children: partner.name || t(lang, "partnerName")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 tabular-nums text-muted",
						children: status
					}),
					call.phase === "outgoing" && !p2p?.peers.some((p) => p.connectionState === "connected") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xs text-center text-sm text-subtle",
						children: t(lang, "noPeerCall")
					}) : null
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "absolute top-8 left-0 right-0 text-center font-display text-xl tabular-nums",
					children: [
						partner.name,
						" · ",
						status
					]
				})
			}),
			isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: localRef,
				className: "absolute right-4 bottom-36 z-10 h-40 w-28 rounded-xl object-cover ring-1 ring-border",
				autoPlay: true,
				muted: true,
				playsInline: true
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: localRef,
				className: "sr-only",
				autoPlay: true,
				muted: true,
				playsInline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				ref: isVideo ? void 0 : remoteRef,
				className: "sr-only",
				autoPlay: true,
				playsInline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-10 flex items-center justify-center gap-4 pb-[max(2rem,env(safe-area-inset-bottom))]",
				children: call.phase === "incoming" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					size: "icon",
					className: "size-16",
					"aria-label": t(lang, "decline"),
					onClick: () => hangup("decline"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-6" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "icon",
					className: "size-16",
					"aria-label": t(lang, "accept"),
					onClick: () => void onAccept(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "size-6" })
				})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						size: "icon",
						className: "size-14",
						"aria-label": muted ? t(lang, "unmute") : t(lang, "mute"),
						onClick: toggleMute,
						children: muted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MicOff, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mic, { className: "size-5" })
					}),
					isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "surface",
						size: "icon",
						className: "size-14",
						"aria-label": camOff ? t(lang, "cameraOn") : t(lang, "cameraOff"),
						onClick: toggleCam,
						children: camOff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoOff, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Video, { className: "size-5" })
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "danger",
						size: "icon",
						className: "size-16",
						"aria-label": t(lang, "endCall"),
						onClick: () => hangup("end"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneOff, { className: "size-6" })
					})
				] })
			})
		]
	});
}
var TABS = [
	{
		id: "chat",
		icon: MessageCircle,
		label: "chat"
	},
	{
		id: "photos",
		icon: Image,
		label: "photos"
	},
	{
		id: "videos",
		icon: Film,
		label: "videos"
	},
	{
		id: "notes",
		icon: NotebookPen,
		label: "notes"
	},
	{
		id: "settings",
		icon: Settings,
		label: "settings"
	}
];
function AppShell() {
	const settings = useApp((s) => s.settings);
	const tab = useApp((s) => s.tab);
	const setTab = useApp((s) => s.setTab);
	const wallpaperUrl = useBlobUrl(settings.wallpaperId);
	const lang = settings.lang;
	(0, import_react.useEffect)(() => {
		const root = document.documentElement;
		root.style.setProperty("--accent", settings.accent);
		root.style.setProperty("--accent-fg", accentForeground(settings.accent));
		root.lang = lang === "my" ? "my" : lang === "th" ? "th" : "en";
	}, [settings.accent, lang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh overflow-hidden bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: wallpaperUrl || "/wallpaper.jpg",
				alt: "",
				className: "pointer-events-none absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0",
				style: { background: `color-mix(in oklab, var(--bg) ${Math.round(settings.wallpaperDim * 100)}%, transparent)` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto flex h-dvh max-w-lg flex-col bg-bg/20",
				children: [
					tab === "chat" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatView, {}) : null,
					tab === "photos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhotosView, {}) : null,
					tab === "videos" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideosView, {}) : null,
					tab === "notes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotesView, {}) : null,
					tab === "settings" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsView, {}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "grid grid-cols-5 border-t border-border bg-bg-elevated/90 pb-[env(safe-area-inset-bottom)]",
						children: TABS.map(({ id, icon: Icon, label }) => {
							const active = tab === id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setTab(id),
								className: cn("flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]", active ? "text-accent" : "text-subtle"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
									className: "size-5",
									strokeWidth: active ? 2.2 : 1.7
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: t(lang, label) })]
							}, id);
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CallOverlay, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center",
				toastOptions: { className: "bg-surface text-fg border-border" }
			})
		]
	}) });
}
function Home() {
	const ready = useApp((s) => s.ready);
	const onboarded = useApp((s) => s.settings.onboarded);
	const hydrate = useApp((s) => s.hydrate);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-bg text-fg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
				className: "size-7 fill-accent text-accent",
				strokeWidth: 1.5
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Two of Us"
			})]
		})
	});
	if (!onboarded) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Onboarding, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { downloadBlob as a, Home as component, dataUrlToBlob as i, chunkDataUrl as n, routes_Z4N11j_o_exports as o, compressImage as r, blobToDataUrl as t };
