//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D6rpwjgw.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/rtc"],
		preloads: ["/assets/index-DRz_ULAt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DRz_ULAt.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-D0CDp0v_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
