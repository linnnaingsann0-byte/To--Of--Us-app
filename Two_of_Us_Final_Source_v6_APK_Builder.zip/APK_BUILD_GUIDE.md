# Two of Us — Android APK build

This source package includes a GitHub Actions workflow at `.github/workflows/android-apk.yml`.

The workflow builds a debug APK in the cloud. It does not require a computer with Android Studio.

Important: the web app uses `/api/rtc` and server-side relay features. For real two-phone communication, the web app must be deployed to a server that supports those routes. A Capacitor APK by itself does not replace that backend.
