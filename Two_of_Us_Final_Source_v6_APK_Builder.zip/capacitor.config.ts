import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.twoofus.private",
  appName: "Two of Us",
  webDir: "dist/client",
  bundledWebRuntime: false,
  android: { allowMixedContent: false },
};
export default config;
