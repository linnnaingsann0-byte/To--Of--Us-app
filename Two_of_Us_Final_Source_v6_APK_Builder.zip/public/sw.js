const CACHE = "two-of-us-shell-v4";
const APP_SHELL = ["/", "/favicon.svg", "/wallpaper.jpg"];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener("activate", (event) => event.waitUntil(self.clients.claim()));
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(caches.match(event.request).then((cached) => cached || fetch(event.request).then((response) => {
    const copy = response.clone();
    caches.open(CACHE).then((cache) => cache.put(event.request, copy));
    return response;
  }).catch(() => cached)));
});

function readSettings() {
  return new Promise((resolve) => {
    const req = indexedDB.open("two-of-us", 1);
    req.onsuccess = () => {
      const db = req.result;
      const get = db.transaction("kv", "readonly").objectStore("kv").get("settings");
      get.onsuccess = () => resolve(get.result || null);
      get.onerror = () => resolve(null);
    };
    req.onerror = () => resolve(null);
  });
}

function readValue(key) {
  return new Promise((resolve) => {
    const req = indexedDB.open("two-of-us", 1);
    req.onsuccess = () => {
      const db = req.result;
      const get = db.transaction("kv", "readonly").objectStore("kv").get(key);
      get.onsuccess = () => resolve(get.result);
      get.onerror = () => resolve(undefined);
    };
    req.onerror = () => resolve(undefined);
  });
}

function writeValue(key, value) {
  return new Promise((resolve) => {
    const req = indexedDB.open("two-of-us", 1);
    req.onsuccess = () => {
      const db = req.result;
      const tx = db.transaction("kv", "readwrite");
      tx.objectStore("kv").put(value, key);
      tx.oncomplete = resolve;
      tx.onerror = resolve;
    };
    req.onerror = resolve;
  });
}

async function checkAnniversary() {
  const settings = await readSettings();
  if (!settings?.relationshipStartDate || settings.relationshipReminder === false) return;
  const now = new Date();
  const [year, month, day] = settings.relationshipStartDate.split("-").map(Number);
  if (!year || !month || !day || now.getDate() !== day) return;
  const hour = Number.isFinite(settings.relationshipReminderHour) ? settings.relationshipReminderHour : 9;
  if (now.getHours() !== hour) return;
  const key = `two-of-us-anniversary-${settings.relationshipStartDate}-${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`;
  const sent = await readValue(key);
  if (sent) return;
  await writeValue(key, 1);
  if (self.registration.showNotification) {
    await self.registration.showNotification("Two of Us 💕", {
      body: "ဒီနေ့က ငါတို့နှစ်ယောက်ရဲ့ လစဉ်အမှတ်တရနေ့လေးပါ။",
      icon: "/favicon.svg",
      badge: "/favicon.svg",
      tag: "two-of-us-monthly-anniversary",
    });
  }
}

self.addEventListener("periodicsync", (event) => {
  if (event.tag === "two-of-us-monthly") event.waitUntil(checkAnniversary());
});
self.addEventListener("message", (event) => {
  if (event.data?.type === "CHECK_ANNIVERSARY") event.waitUntil(checkAnniversary());
});
