import { useEffect } from "react";
import { Film, Image, MessageCircle, NotebookPen, Settings } from "lucide-react";
import { Toaster } from "sonner";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { accentForeground, cn } from "@/lib/utils";
import { useBlobUrl } from "@/lib/use-blob-url";
import type { Tab } from "@/lib/types";
import { ChatView } from "@/components/chat-view";
import { PhotosView } from "@/components/photos-view";
import { VideosView } from "@/components/videos-view";
import { NotesView } from "@/components/notes-view";
import { SettingsView } from "@/components/settings-view";
import { CallOverlay } from "@/components/call-overlay";
import { LinkProvider } from "@/components/link-provider";

const TABS: { id: Tab; icon: typeof MessageCircle; label: "chat" | "photos" | "videos" | "notes" | "settings" }[] = [
  { id: "chat", icon: MessageCircle, label: "chat" },
  { id: "photos", icon: Image, label: "photos" },
  { id: "videos", icon: Film, label: "videos" },
  { id: "notes", icon: NotebookPen, label: "notes" },
  { id: "settings", icon: Settings, label: "settings" },
];

export function AppShell() {
  const settings = useApp((s) => s.settings);
  const tab = useApp((s) => s.tab);
  const setTab = useApp((s) => s.setTab);
  const wallpaperUrl = useBlobUrl(settings.wallpaperId);
  const lang = settings.lang;

  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--accent", settings.accent);
    root.style.setProperty("--accent-fg", accentForeground(settings.accent));
    root.lang = lang === "my" ? "my" : lang === "th" ? "th" : "en";
  }, [settings.accent, lang]);

  return (
    <LinkProvider>
      <div className="relative min-h-dvh overflow-hidden bg-bg text-fg">
        <img
          src={wallpaperUrl || "/wallpaper.jpg"}
          alt=""
          className="pointer-events-none absolute inset-0 size-full object-cover"
        />
        <div
          className="pointer-events-none absolute inset-0"
          style={{ background: `color-mix(in oklab, var(--bg) ${Math.round(settings.wallpaperDim * 100)}%, transparent)` }}
        />
        <div className="relative mx-auto flex h-dvh max-w-lg flex-col bg-bg/20">
          {tab === "chat" ? <ChatView /> : null}
          {tab === "photos" ? <PhotosView /> : null}
          {tab === "videos" ? <VideosView /> : null}
          {tab === "notes" ? <NotesView /> : null}
          {tab === "settings" ? <SettingsView /> : null}

          <nav className="grid grid-cols-5 border-t border-border bg-bg-elevated/90 pb-[env(safe-area-inset-bottom)]">
            {TABS.map(({ id, icon: Icon, label }) => {
              const active = tab === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => setTab(id)}
                  className={cn(
                    "flex min-h-14 flex-col items-center justify-center gap-1 text-[11px]",
                    active ? "text-accent" : "text-subtle",
                  )}
                >
                  <Icon className="size-5" strokeWidth={active ? 2.2 : 1.7} />
                  <span>{t(lang, label)}</span>
                </button>
              );
            })}
          </nav>
        </div>
        <CallOverlay />
        <Toaster
          theme="dark"
          position="top-center"
          toastOptions={{
            className: "bg-surface text-fg border-border",
          }}
        />
      </div>
    </LinkProvider>
  );
}
