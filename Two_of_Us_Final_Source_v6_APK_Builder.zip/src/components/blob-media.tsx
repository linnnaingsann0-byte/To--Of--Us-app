import { cn } from "@/lib/utils";
import { useBlobUrl } from "@/lib/use-blob-url";

export function BlobImage({
  id,
  alt,
  className,
}: {
  id?: string;
  alt: string;
  className?: string;
}) {
  const url = useBlobUrl(id);
  if (!url) return <div className={cn("bg-surface", className)} aria-hidden />;
  return <img src={url} alt={alt} className={className} />;
}

export function BlobVideo({
  id,
  className,
  controls = true,
  muted,
  autoPlay,
}: {
  id?: string;
  className?: string;
  controls?: boolean;
  muted?: boolean;
  autoPlay?: boolean;
}) {
  const url = useBlobUrl(id);
  if (!url) return <div className={cn("bg-surface", className)} aria-hidden />;
  return (
    <video
      src={url}
      className={className}
      controls={controls}
      playsInline
      muted={muted}
      autoPlay={autoPlay}
    />
  );
}
