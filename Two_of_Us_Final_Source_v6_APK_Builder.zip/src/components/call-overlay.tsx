import { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Phone, PhoneOff, Video, VideoOff } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { formatDuration } from "@/lib/utils";
import { startRingtone } from "@/lib/ringtone";
import { Button } from "@/components/ui/button";
import { PersonAvatar } from "@/components/person-avatar";
import { sendCallSignal, useLink } from "@/components/link-provider";
import { toast } from "sonner";

export function CallOverlay() {
  const call = useApp((s) => s.call);
  const settings = useApp((s) => s.settings);
  const acceptCall = useApp((s) => s.acceptCall);
  const endCall = useApp((s) => s.endCall);
  const p2p = useLink();
  const lang = settings.lang;
  const partner = settings.partner;
  const localRef = useRef<HTMLVideoElement>(null);
  const remoteRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const [now, setNow] = useState(Date.now());
  const [remoteOn, setRemoteOn] = useState(false);

  const active = call.phase !== "idle";
  const isVideo = call.kind === "video";

  useEffect(() => {
    if (!active) return;
    const id = window.setInterval(() => setNow(Date.now()), 500);
    return () => window.clearInterval(id);
  }, [active]);

  useEffect(() => {
    if (call.phase !== "incoming" && call.phase !== "outgoing") return;
    return startRingtone();
  }, [call.phase]);

  useEffect(() => {
    if (!p2p) return;
    return p2p.onTrack((_from, ev) => {
      const el = remoteRef.current;
      const stream = ev.streams[0] ?? new MediaStream([ev.track]);
      if (el) el.srcObject = stream;
      setRemoteOn(true);
    });
  }, [p2p]);

  async function acquire() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: isVideo ? { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } } : false,
      });
      streamRef.current = stream;
      if (localRef.current) localRef.current.srcObject = stream;
      p2p?.setLocalStream(stream);
      return true;
    } catch {
      toast.error(isVideo ? t(lang, "cameraBlocked") : t(lang, "microphoneBlocked"));
      return false;
    }
  }

  useEffect(() => {
    if (call.phase === "outgoing") {
      void acquire();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [call.phase, call.kind]);

  useEffect(() => {
    if (call.phase !== "idle") return;
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
    streamRef.current = null;
    p2p?.setLocalStream(null);
    setRemoteOn(false);
    setMuted(false);
    setCamOff(false);
  }, [call.phase, p2p]);

  if (!active) return null;

  async function onAccept() {
    const ok = await acquire();
    if (!ok) return;
    sendCallSignal(p2p, "accept", call.kind);
    acceptCall();
  }

  function hangup(action: "end" | "decline") {
    streamRef.current?.getTracks().forEach((tr) => tr.stop());
    streamRef.current = null;
    p2p?.setLocalStream(null);
    sendCallSignal(p2p, action, call.kind);
    endCall();
    setRemoteOn(false);
  }

  function toggleMute() {
    const next = !muted;
    setMuted(next);
    streamRef.current?.getAudioTracks().forEach((tr) => {
      tr.enabled = !next;
    });
    const track = streamRef.current?.getAudioTracks()[0];
    p2p?.replaceTrack("audio", next ? null : track ?? null);
  }

  function toggleCam() {
    const next = !camOff;
    setCamOff(next);
    streamRef.current?.getVideoTracks().forEach((tr) => {
      tr.enabled = !next;
    });
    const track = streamRef.current?.getVideoTracks()[0];
    p2p?.replaceTrack("video", next ? null : track ?? null);
  }

  const status =
    call.phase === "incoming"
      ? t(lang, "incomingCall")
      : call.phase === "outgoing"
        ? t(lang, "outgoingCall")
        : call.startedAt
          ? formatDuration(now - call.startedAt)
          : t(lang, "connected");

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-bg text-fg">
      {isVideo ? (
        <video
          ref={remoteRef}
          className="absolute inset-0 size-full object-cover"
          autoPlay
          playsInline
        />
      ) : null}
      {!remoteOn || !isVideo ? (
        <div className="absolute inset-0">
          <img src="/wallpaper.jpg" alt="" className="size-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-bg/60" />
        </div>
      ) : null}

      <div className="relative flex flex-1 flex-col items-center justify-center px-6 pt-[max(2.5rem,env(safe-area-inset-top))]">
        {!remoteOn || call.phase !== "active" || !isVideo ? (
          <>
            <PersonAvatar name={partner.name} avatarId={partner.avatarId} className="size-28" />
            <h1 className="mt-5 font-display text-3xl font-medium">{partner.name || t(lang, "partnerName")}</h1>
            <p className="mt-2 tabular-nums text-muted">{status}</p>
            {call.phase === "outgoing" && !p2p?.peers.some((p) => p.connectionState === "connected") ? (
              <p className="mt-4 max-w-xs text-center text-sm text-subtle">{t(lang, "noPeerCall")}</p>
            ) : null}
          </>
        ) : (
          <p className="absolute top-8 left-0 right-0 text-center font-display text-xl tabular-nums">
            {partner.name} · {status}
          </p>
        )}
      </div>

      {isVideo ? (
        <video
          ref={localRef}
          className="absolute right-4 bottom-36 z-10 h-40 w-28 rounded-xl object-cover ring-1 ring-border"
          autoPlay
          muted
          playsInline
        />
      ) : (
        <video ref={localRef} className="sr-only" autoPlay muted playsInline />
      )}
      <video ref={isVideo ? undefined : remoteRef} className="sr-only" autoPlay playsInline />

      <div className="relative z-10 flex items-center justify-center gap-4 pb-[max(2rem,env(safe-area-inset-bottom))]">
        {call.phase === "incoming" ? (
          <>
            <Button
              variant="danger"
              size="icon"
              className="size-16"
              aria-label={t(lang, "decline")}
              onClick={() => hangup("decline")}
            >
              <PhoneOff className="size-6" />
            </Button>
            <Button
              size="icon"
              className="size-16"
              aria-label={t(lang, "accept")}
              onClick={() => void onAccept()}
            >
              <Phone className="size-6" />
            </Button>
          </>
        ) : (
          <>
            <Button
              variant="surface"
              size="icon"
              className="size-14"
              aria-label={muted ? t(lang, "unmute") : t(lang, "mute")}
              onClick={toggleMute}
            >
              {muted ? <MicOff className="size-5" /> : <Mic className="size-5" />}
            </Button>
            {isVideo ? (
              <Button
                variant="surface"
                size="icon"
                className="size-14"
                aria-label={camOff ? t(lang, "cameraOn") : t(lang, "cameraOff")}
                onClick={toggleCam}
              >
                {camOff ? <VideoOff className="size-5" /> : <Video className="size-5" />}
              </Button>
            ) : null}
            <Button
              variant="danger"
              size="icon"
              className="size-16"
              aria-label={t(lang, "endCall")}
              onClick={() => hangup("end")}
            >
              <PhoneOff className="size-6" />
            </Button>
          </>
        )}
      </div>
    </div>
  );
}
