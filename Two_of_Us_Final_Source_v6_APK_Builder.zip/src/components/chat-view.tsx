import { useEffect, useRef, useState, type FormEvent } from "react";
import { ImagePlus, Phone, Send, Video, Reply, Trash2, X } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { cn, formatDay, formatTime } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { PersonAvatar } from "@/components/person-avatar";
import { BlobImage, BlobVideo } from "@/components/blob-media";
import { deleteChatOverLink, sendCallSignal, sendChatOverLink, useLink } from "@/components/link-provider";
import { RelationshipCard } from "@/components/relationship-card";
import { useBlobUrl } from "@/lib/use-blob-url";
import type { Message } from "@/lib/types";

export function ChatView() {
  const settings = useApp((s) => s.settings);
  const messages = useApp((s) => s.messages);
  const sendMessage = useApp((s) => s.sendMessage);
  const saveMedia = useApp((s) => s.saveMessageMedia);
  const deleteMessage = useApp((s) => s.deleteMessage);
  const startCall = useApp((s) => s.startCall);
  const patch = useApp((s) => s.patchSettings);
  const lang = settings.lang;
  const chatWallpaperUrl = useBlobUrl(settings.chatWallpaperId);
  const p2p = useLink();
  const [draft, setDraft] = useState("");
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const photoRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);
  const online = p2p?.peers.some((p) => p.connectionState === "connected") ?? false;

  useEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length]);

  async function submit(e?: FormEvent, media?: { blob: File; kind: "image" | "video" }) {
    e?.preventDefault();
    const text = draft;
    if (!text.trim() && !media) return;
    setDraft("");
    const msg = await sendMessage(text, media, replyTo?.id);
    setReplyTo(null);
    await sendChatOverLink(p2p, msg);
  }

  function beginCall(kind: "audio" | "video") {
    startCall(kind);
    sendCallSignal(p2p, "invite", kind);
  }

  const them = settings.activeRole === "me" ? settings.partner : settings.me;

  return (
    <div className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
      {chatWallpaperUrl ? <img src={chatWallpaperUrl} alt="" className="pointer-events-none absolute inset-0 size-full object-cover opacity-35" /> : null}
      <div className="pointer-events-none absolute inset-0 bg-bg/45" />
      <div className="relative flex min-h-0 flex-1 flex-col">
      <header className="flex items-center gap-3 border-b border-border px-4 py-3">
        <PersonAvatar name={them.name} avatarId={them.avatarId} className="size-10" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium leading-tight">{them.name || t(lang, "partnerName")}</p>
          <p className="flex items-center gap-1.5 text-xs text-muted">
            <span className={cn("size-1.5 rounded-full", online ? "bg-accent" : "bg-subtle")} />
            {online ? t(lang, "partnerOnline") : t(lang, "waitingPartner")}
          </p>
        </div>
        <Button variant="ghost" size="icon-sm" aria-label={t(lang, "call")} onClick={() => beginCall("audio")}>
          <Phone className="size-5" />
        </Button>
        <Button variant="ghost" size="icon-sm" aria-label={t(lang, "videoCall")} onClick={() => beginCall("video")}>
          <Video className="size-5" />
        </Button>
      </header>

      <RelationshipCard />

      <div className="flex items-center gap-2 border-b border-border px-4 py-2">
        <p className="text-xs text-subtle">{t(lang, "sendingAs")}</p>
        <RoleChip
          active={settings.activeRole === "me"}
          name={settings.me.name || t(lang, "iAmMe")}
          avatarId={settings.me.avatarId}
          onClick={() => patch({ activeRole: "me" })}
        />
        <RoleChip
          active={settings.activeRole === "partner"}
          name={settings.partner.name || t(lang, "iAmPartner")}
          avatarId={settings.partner.avatarId}
          onClick={() => patch({ activeRole: "partner" })}
        />
      </div>

      <div ref={scroller} className="min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4">
        {messages.length === 0 ? (
          <p className="pt-16 text-center text-sm text-muted">{t(lang, "emptyChat")}</p>
        ) : (
          messages.map((m, i) => {
            const showDay =
              i === 0 || formatDay(m.createdAt, lang) !== formatDay(messages[i - 1].createdAt, lang);
            const mine = m.from === settings.activeRole;
            return (
              <div key={m.id}>
                {showDay ? (
                  <p className="mb-3 text-center text-xs text-subtle">{formatDay(m.createdAt, lang)}</p>
                ) : null}
                <Bubble
                  msg={m}
                  mine={mine}
                  lang={lang}
                  time={formatTime(m.createdAt, lang)}
                  reply={m.replyToId ? messages.find((x) => x.id === m.replyToId) : undefined}
                  onSave={() => void saveMedia(m.id)}
                  onReply={() => setReplyTo(m)}
                  onDelete={() => { deleteMessage(m.id); void deleteChatOverLink(p2p, m.id); }}
                />
              </div>
            );
          })
        )}
      </div>

      {replyTo ? (
        <div className="flex items-center gap-2 border-t border-border bg-surface/80 px-3 py-2">
          <Reply className="size-4 text-accent" />
          <p className="min-w-0 flex-1 truncate text-sm">{replyTo.text || (replyTo.mediaKind === "video" ? "🎥 Video" : "📷 Photo")}</p>
          <button type="button" onClick={() => setReplyTo(null)} aria-label="Cancel reply"><X className="size-4" /></button>
        </div>
      ) : null}
      <form
        onSubmit={(e) => void submit(e)}
        className="flex items-end gap-2 border-t border-border px-3 py-3"
      >
        <input
          ref={photoRef}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void submit(undefined, { blob: f, kind: "image" });
            e.target.value = "";
          }}
        />
        <input
          ref={videoRef}
          type="file"
          accept="video/*"
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) void submit(undefined, { blob: f, kind: "video" });
            e.target.value = "";
          }}
        />
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          aria-label={t(lang, "attachPhoto")}
          onClick={() => photoRef.current?.click()}
        >
          <ImagePlus className="size-5" />
        </Button>
        <Button
          type="button"
          variant="ghost"
          size="icon-sm"
          aria-label={t(lang, "attachVideo")}
          onClick={() => videoRef.current?.click()}
        >
          <Video className="size-5" />
        </Button>
        <textarea
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              void submit();
            }
          }}
          rows={1}
          placeholder={t(lang, "typeMessage")}
          className="max-h-28 min-h-11 flex-1 resize-none rounded-lg border border-border bg-surface px-3 py-2.5 text-base text-fg placeholder:text-subtle focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/70"
        />
        <Button type="submit" size="icon" aria-label={t(lang, "send")} disabled={!draft.trim()}>
          <Send className="size-4" />
        </Button>
      </form>
      </div>
    </div>
  );
}

function RoleChip({
  active,
  name,
  avatarId,
  onClick,
}: {
  active: boolean;
  name: string;
  avatarId?: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "flex items-center gap-1.5 rounded-full py-1 pr-2.5 pl-1 text-xs transition-colors duration-150",
        active ? "bg-accent text-accent-fg" : "bg-surface text-muted",
      )}
    >
      <PersonAvatar name={name} avatarId={avatarId} className="size-5" />
      <span className="max-w-20 truncate">{name}</span>
    </button>
  );
}

function Bubble({
  msg,
  mine,
  lang,
  time,
  reply,
  onSave,
  onReply,
  onDelete,
}: {
  msg: Message;
  mine: boolean;
  lang: Parameters<typeof t>[0];
  time: string;
  reply?: Message;
  onSave: () => void;
  onReply: () => void;
  onDelete: () => void;
}) {
  return (
    <div className={cn("flex", mine ? "justify-end" : "justify-start")}>
      <div
        className={cn(
          "max-w-[78%] overflow-hidden rounded-2xl",
          mine ? "rounded-br-sm bg-accent text-accent-fg" : "rounded-bl-sm bg-surface text-fg",
        )}
      >
        {msg.deletedAt ? <p className="px-3 py-3 text-sm italic opacity-70">Message deleted</p> : null}
        {reply ? <div className="mx-2 mt-2 rounded-lg bg-black/10 px-2 py-1 text-xs opacity-80">↩ {reply.text || (reply.mediaKind === "video" ? "Video" : "Photo")}</div> : null}
        {!msg.deletedAt && msg.mediaKind === "image" && msg.mediaId ? (
          <BlobImage id={msg.mediaId} alt="" className="max-h-72 w-full object-cover" />
        ) : null}
        {!msg.deletedAt && msg.mediaKind === "video" && msg.mediaId ? (
          <BlobVideo id={msg.mediaId} className="max-h-72 w-full" />
        ) : null}
        {!msg.deletedAt && msg.text ? <p className="px-3 py-2 text-[0.95rem] leading-snug">{msg.text}</p> : null}
        <div className={cn("flex items-center justify-end gap-2 px-3 pb-1.5", msg.text ? "" : "pt-1.5")}>
          {msg.mediaId && !msg.saved ? (
            <button
              type="button"
              onClick={onSave}
              className={cn("text-[11px] underline-offset-2 hover:underline", mine ? "text-accent-fg/80" : "text-muted")}
            >
              {msg.mediaKind === "video" ? t(lang, "saveToVideos") : t(lang, "saveToPhotos")}
            </button>
          ) : null}
          {msg.saved ? (
            <span className={cn("text-[11px]", mine ? "text-accent-fg/70" : "text-subtle")}>{t(lang, "saved")}</span>
          ) : null}
          <span className={cn("text-[11px] tabular-nums", mine ? "text-accent-fg/70" : "text-subtle")}>{time}</span>
          <button type="button" onClick={onReply} className="opacity-80" aria-label="Reply"><Reply className="size-3.5" /></button>
          {mine && !msg.deletedAt ? <button type="button" onClick={onDelete} className="opacity-80" aria-label="Delete"><Trash2 className="size-3.5" /></button> : null}
        </div>
      </div>
    </div>
  );
}
