import { createContext, useContext, useEffect, useMemo, useRef, type ReactNode } from "react";
import { toast } from "sonner";
import { useP2PRoom, type P2PRoomHandle } from "@/lib/multiplayer";
import { useApp } from "@/lib/store";
import { blobGet, kvGet, kvSet } from "@/lib/idb";
import { blobToDataUrl, chunkDataUrl, dataUrlToBlob } from "@/lib/media";
import { t } from "@/lib/i18n";
import type { AlbumItem, CallKind, Message, Note } from "@/lib/types";

type Wire =
  | { t: "hello"; role: "me" | "partner"; name: string }
  | { t: "chat"; msg: Message; media?: string }
  | { t: "media-meta"; id: string; mime: string; n: number; msg: Message }
  | { t: "media-chunk"; id: string; i: number; chunk: string }
  | { t: "note-sync"; notes: Note[] }
  | { t: "album"; item: AlbumItem; media: string }
  | { t: "call"; action: "invite" | "accept" | "decline" | "end"; kind: CallKind };

const LinkCtx = createContext<P2PRoomHandle | null>(null);

export function useLink() {
  return useContext(LinkCtx);
}

export function LinkProvider({ children }: { children: ReactNode }) {
  const onboarded = useApp((s) => s.settings.onboarded);
  const code = useApp((s) => s.settings.coupleCode);
  const name = useApp((s) => s.settings.me.name);
  const room = `us-${code}`.slice(0, 64);

  if (!onboarded || !code) return <>{children}</>;

  return (
    <LinkInner key={room} room={room} name={name || "me"}>
      {children}
    </LinkInner>
  );
}

function LinkInner({ room, name, children }: { room: string; name: string; children: ReactNode }) {
  const p2p = useP2PRoom({ room, name, enabled: true });
  const ingest = useApp((s) => s.ingestRemoteMessage);
  const applyNotes = useApp((s) => s.applyRemoteNotes);
  const applyAlbum = useApp((s) => s.applyRemoteAlbum);
  const receiveCall = useApp((s) => s.receiveCall);
  const acceptCall = useApp((s) => s.acceptCall);
  const endCall = useApp((s) => s.endCall);
  const callPhase = useApp((s) => s.call.phase);
  const lang = useApp((s) => s.settings.lang);
  const role = useApp((s) => s.settings.activeRole);
  const chunks = useRef(new Map<string, { parts: string[]; n: number; msg: Message }>());

  const callPhaseRef = useRef(callPhase);
  callPhaseRef.current = callPhase;

  useEffect(() => {
    return p2p.onMessage((_from, data) => {
      const msg = data as Wire;
      if (!msg || typeof msg !== "object") return;
      if ("__relay" in msg) {
        const rel = msg as { __relay: true; payload: unknown };
        const payload = rel.payload as Wire | { __delete?: string };
        if (payload && typeof payload === "object" && "__delete" in payload && payload.__delete) {
          useApp.getState().deleteMessage(payload.__delete);
          return;
        }
        if (payload && typeof payload === "object" && "t" in payload) {
          const wire = payload as Wire;
          if (wire.t === "chat") void ingest(wire.msg, wire.media);
        }
        return;
      }
      if ("__delete" in msg && (msg as { __delete?: string }).__delete) {
        useApp.getState().deleteMessage((msg as { __delete: string }).__delete);
        return;
      }
      if (!("t" in msg)) return;
      if (msg.t === "chat") {
        void ingest(msg.msg, msg.media);
      } else if (msg.t === "media-meta") {
        chunks.current.set(msg.id, { parts: Array(msg.n).fill(""), n: msg.n, msg: msg.msg });
      } else if (msg.t === "media-chunk") {
        const buf = chunks.current.get(msg.id);
        if (!buf) return;
        buf.parts[msg.i] = msg.chunk;
        if (buf.parts.every(Boolean)) {
          const dataUrl = buf.parts.join("");
          chunks.current.delete(msg.id);
          void ingest(buf.msg, dataUrl);
        }
      } else if (msg.t === "note-sync") {
        applyNotes(msg.notes);
      } else if (msg.t === "album") {
        void applyAlbum(msg.item, msg.media);
      } else if (msg.t === "call") {
        if (msg.action === "invite" && callPhaseRef.current === "idle") receiveCall(msg.kind);
        if (msg.action === "accept") acceptCall();
        if (msg.action === "decline" || msg.action === "end") endCall();
      } else if (msg.t === "hello") {
        /* roster already carries the name */
      }
    });
  }, [p2p, ingest, applyNotes, applyAlbum, receiveCall, acceptCall, endCall]);

  useEffect(() => {
    void flushPendingChatRelay();
    const connected = p2p.peers.some((p) => p.connectionState === "connected");
    if (!connected) return;
    p2p.send({ t: "hello", role, name } satisfies Wire);
    p2p.send({ t: "note-sync", notes: useApp.getState().notes } satisfies Wire);
  }, [p2p, p2p.peers, role, name]);

  useEffect(() => {
    const live = p2p.peers.some((p) => p.connectionState === "connected");
    if (live) toast.success(t(lang, "partnerOnline"));
  }, [p2p.peers.some((p) => p.connectionState === "connected")]);

  return <LinkCtx.Provider value={p2p}>{children}</LinkCtx.Provider>;
}

type PendingRelay = { room: string; from: string; payload: Wire };
const PENDING_KEY = "pending-chat-relay";

async function relayToServer(room: string, from: string, payload: Wire): Promise<boolean> {
  if (!room || !from) return false;
  try {
    const res = await fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ op: "message", room, from, payload }),
    });
    if (!res.ok) throw new Error(`relay failed: ${res.status}`);
    return true;
  } catch {
    const pending = (await kvGet<PendingRelay[]>(PENDING_KEY)) ?? [];
    if (!pending.some((x) => (x.payload as Wire & { msg?: Message }).msg?.id === (payload as Wire & { msg?: Message }).msg?.id)) {
      pending.push({ room, from, payload });
      await kvSet(PENDING_KEY, pending.slice(-50));
    }
    return false;
  }
}

export async function flushPendingChatRelay() {
  const pending = (await kvGet<PendingRelay[]>(PENDING_KEY)) ?? [];
  if (!pending.length) return;
  const left: PendingRelay[] = [];
  for (const item of pending) {
    if (!(await relayToServer(item.room, item.from, item.payload))) left.push(item);
  }
  await kvSet(PENDING_KEY, left);
}

export async function sendChatOverLink(
  p2p: P2PRoomHandle | null,
  msg: Message,
) {
  let media: string | undefined;
  if (msg.mediaId) {
    const blob = await blobGet(msg.mediaId);
    if (blob) media = await blobToDataUrl(blob);
  }
  const payload: Wire = { t: "chat", msg, media };
  // Persistent mailbox: the partner can receive it even if they are offline.
  await relayToServer(p2p?.room ?? "", p2p?.selfId ?? "", payload);
  await flushPendingChatRelay();
  if (!p2p || p2p.peers.every((p) => p.connectionState !== "connected")) return;
  // Fast path while both apps are open.
  if (media && media.length > 14_000) {
    const parts = chunkDataUrl(media);
    p2p.send({ t: "media-meta", id: msg.id, mime: dataUrlToBlob(media).type, n: parts.length, msg });
    parts.forEach((chunk, i) => p2p.send({ t: "media-chunk", id: msg.id, i, chunk }));
    return;
  }
  p2p.send(payload);
}

export async function deleteChatOverLink(p2p: P2PRoomHandle | null, messageId: string) {
  if (!p2p) return;
  try {
    await fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ op: "message-delete", room: p2p.room, from: p2p.selfId, messageId }),
    });
  } catch {
    // Local deletion still applies.
  }
  p2p.send({ __delete: messageId } as unknown as Wire);
}

export async function sendAlbumOverLink(p2p: P2PRoomHandle | null, item: AlbumItem) {
  if (!p2p || p2p.peers.every((p) => p.connectionState !== "connected")) return;
  const blob = await blobGet(item.blobId);
  if (!blob || blob.size > 2_400_000) return;
  const media = await blobToDataUrl(blob);
  p2p.send({ t: "album", item, media });
}

export function sendNotesOverLink(p2p: P2PRoomHandle | null, notes: Note[]) {
  if (!p2p) return;
  p2p.send({ t: "note-sync", notes });
}

export function sendCallSignal(
  p2p: P2PRoomHandle | null,
  action: "invite" | "accept" | "decline" | "end",
  kind: CallKind,
) {
  p2p?.send({ t: "call", action, kind } satisfies Wire);
}
