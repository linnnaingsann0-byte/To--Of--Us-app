import { useState } from "react";
import { Pin, Plus, Trash2 } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { cn, formatDay } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { sendNotesOverLink, useLink } from "@/components/link-provider";
import type { Note } from "@/lib/types";

export function NotesView() {
  const notes = useApp((s) => s.notes);
  const lang = useApp((s) => s.settings.lang);
  const addNote = useApp((s) => s.addNote);
  const updateNote = useApp((s) => s.updateNote);
  const removeNote = useApp((s) => s.removeNote);
  const p2p = useLink();
  const [editing, setEditing] = useState<Note | "new" | null>(null);

  const sorted = [...notes].sort((a, b) => Number(b.pinned) - Number(a.pinned) || b.updatedAt - a.updatedAt);

  function persist() {
    sendNotesOverLink(p2p, useApp.getState().notes);
  }

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center justify-between px-4 py-4">
        <div>
          <h1 className="font-display text-2xl font-medium">{t(lang, "notes")}</h1>
          <p className="text-sm text-muted">{t(lang, "important")}</p>
        </div>
        <Button size="icon" aria-label={t(lang, "addNote")} onClick={() => setEditing("new")}>
          <Plus className="size-5" />
        </Button>
      </header>
      <div className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 pb-4">
        {sorted.length === 0 ? (
          <p className="pt-16 text-center text-sm text-muted">{t(lang, "emptyNotes")}</p>
        ) : (
          sorted.map((n) => (
            <button
              key={n.id}
              type="button"
              onClick={() => setEditing(n)}
              className="w-full rounded-xl border border-border bg-surface px-4 py-3 text-left"
            >
              <div className="flex items-start gap-2">
                <div className="min-w-0 flex-1">
                  <p className="font-medium leading-snug">{n.title || t(lang, "newNote")}</p>
                  <p className="mt-1 line-clamp-2 text-sm text-muted">{n.body}</p>
                  <p className="mt-2 text-xs text-subtle">{formatDay(n.updatedAt, lang)}</p>
                </div>
                {n.pinned ? <Pin className="size-4 shrink-0 text-accent" /> : null}
              </div>
            </button>
          ))
        )}
      </div>

      {editing ? (
        <NoteEditor
          note={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSave={(title, body) => {
            if (editing === "new") addNote(title, body);
            else updateNote(editing.id, { title, body });
            persist();
            setEditing(null);
          }}
          onDelete={
            editing === "new"
              ? undefined
              : () => {
                  removeNote(editing.id);
                  persist();
                  setEditing(null);
                }
          }
          onPin={
            editing === "new"
              ? undefined
              : () => {
                  updateNote(editing.id, { pinned: !editing.pinned });
                  persist();
                  setEditing({ ...editing, pinned: !editing.pinned });
                }
          }
        />
      ) : null}
    </div>
  );
}

function NoteEditor({
  note,
  onClose,
  onSave,
  onDelete,
  onPin,
}: {
  note: Note | null;
  onClose: () => void;
  onSave: (title: string, body: string) => void;
  onDelete?: () => void;
  onPin?: () => void;
}) {
  const lang = useApp((s) => s.settings.lang);
  const [title, setTitle] = useState(note?.title ?? "");
  const [body, setBody] = useState(note?.body ?? "");

  return (
    <div className="fixed inset-0 z-40 flex items-end justify-center bg-bg/70 sm:items-center">
      <div className="w-full max-w-lg rounded-t-2xl border border-border bg-bg-elevated p-5 pb-[max(1.25rem,env(safe-area-inset-bottom))] sm:rounded-2xl">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-xl">{note ? t(lang, "edit") : t(lang, "newNote")}</h2>
          <div className="flex gap-1">
            {onPin ? (
              <Button variant="ghost" size="icon-sm" aria-label={t(lang, "pin")} onClick={onPin}>
                <Pin className={cn("size-4", note?.pinned && "text-accent")} />
              </Button>
            ) : null}
            {onDelete ? (
              <Button variant="ghost" size="icon-sm" aria-label={t(lang, "delete")} onClick={onDelete}>
                <Trash2 className="size-4 text-danger" />
              </Button>
            ) : null}
          </div>
        </div>
        <Input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder={t(lang, "title")}
          className="mb-3"
        />
        <Textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={t(lang, "body")}
          className="min-h-40"
        />
        <div className="mt-4 flex gap-2">
          <Button variant="outline" className="flex-1" onClick={onClose}>
            {t(lang, "cancel")}
          </Button>
          <Button className="flex-[2]" onClick={() => onSave(title, body)}>
            {t(lang, "save")}
          </Button>
        </div>
      </div>
    </div>
  );
}
