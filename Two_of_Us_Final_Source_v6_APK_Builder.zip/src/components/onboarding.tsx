import { useState } from "react";
import { Heart } from "lucide-react";
import { t } from "@/lib/i18n";
import type { Lang } from "@/lib/types";
import { useApp } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PersonAvatar } from "@/components/person-avatar";
import { cn } from "@/lib/utils";

export function Onboarding() {
  const settings = useApp((s) => s.settings);
  const patch = useApp((s) => s.patchSettings);
  const setPerson = useApp((s) => s.setPerson);
  const setAvatar = useApp((s) => s.setAvatar);
  const lang = settings.lang;
  const [step, setStep] = useState<0 | 1>(0);

  return (
    <div className="relative flex min-h-dvh flex-col">
      <img
        src="/wallpaper.jpg"
        alt=""
        className="pointer-events-none absolute inset-0 size-full object-cover"
      />
      <div className="pointer-events-none absolute inset-0 bg-bg/72" />
      <div className="relative mx-auto flex w-full max-w-lg flex-1 flex-col px-6 pb-10 pt-[max(3rem,env(safe-area-inset-top))]">
        <div className="mb-10 flex items-center gap-2 text-muted">
          <Heart className="size-4 fill-accent text-accent" strokeWidth={1.5} />
          <span className="text-sm tracking-wide">{t(lang, "appName")}</span>
        </div>

        {step === 0 ? (
          <div className="flex flex-1 flex-col">
            <h1 className="font-display text-4xl font-medium leading-tight text-fg">
              {t(lang, "onboardingTitle")}
            </h1>
            <p className="mt-3 max-w-sm text-muted">{t(lang, "onboardingSub")}</p>
            <p className="mt-10 text-sm font-medium text-subtle">{t(lang, "pickLanguage")}</p>
            <div className="mt-3 grid gap-2">
              {(["my", "en", "th"] as const).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => patch({ lang: code })}
                  className={cn(
                    "flex h-14 items-center justify-between rounded-xl border px-4 text-left transition-colors duration-150",
                    lang === code
                      ? "border-accent bg-accent/15 text-fg"
                      : "border-border bg-surface/80 text-muted",
                  )}
                >
                  <span className="text-base font-medium">
                    {code === "my" ? t(lang, "myanmar") : code === "en" ? t(lang, "english") : t(lang, "thai")}
                  </span>
                  {lang === code ? <span className="size-2 rounded-full bg-accent" /> : null}
                </button>
              ))}
            </div>
            <div className="mt-auto pt-10">
              <Button className="w-full" size="lg" onClick={() => setStep(1)}>
                {t(lang, "continue")}
              </Button>
            </div>
          </div>
        ) : (
          <NamesStep
            lang={lang}
            meName={settings.me.name}
            partnerName={settings.partner.name}
            meAvatar={settings.me.avatarId}
            partnerAvatar={settings.partner.avatarId}
            onMe={(v) => setPerson("me", { name: v })}
            onPartner={(v) => setPerson("partner", { name: v })}
            onMePhoto={(f) => void setAvatar("me", f)}
            onPartnerPhoto={(f) => void setAvatar("partner", f)}
            onBack={() => setStep(0)}
            onStart={() =>
              patch({
                onboarded: true,
                me: { ...settings.me, name: settings.me.name.trim() || defaultMe(lang) },
                partner: {
                  ...settings.partner,
                  name: settings.partner.name.trim() || defaultPartner(lang),
                },
              })
            }
          />
        )}
      </div>
    </div>
  );
}

function defaultMe(lang: Lang) {
  return lang === "my" ? "ကိုယ်" : lang === "th" ? "ฉัน" : "Me";
}
function defaultPartner(lang: Lang) {
  return lang === "my" ? "ချစ်သူ" : lang === "th" ? "คนรัก" : "You";
}

function NamesStep({
  lang,
  meName,
  partnerName,
  meAvatar,
  partnerAvatar,
  onMe,
  onPartner,
  onMePhoto,
  onPartnerPhoto,
  onBack,
  onStart,
}: {
  lang: Lang;
  meName: string;
  partnerName: string;
  meAvatar?: string;
  partnerAvatar?: string;
  onMe: (v: string) => void;
  onPartner: (v: string) => void;
  onMePhoto: (f: File) => void;
  onPartnerPhoto: (f: File) => void;
  onBack: () => void;
  onStart: () => void;
}) {
  return (
    <div className="flex flex-1 flex-col">
      <h1 className="font-display text-3xl font-medium leading-tight">{t(lang, "onboardingTitle")}</h1>
      <p className="mt-2 text-muted">{t(lang, "onboardingSub")}</p>
      <div className="mt-8 grid gap-6">
        <NameField
          lang={lang}
          label={t(lang, "myName")}
          name={meName}
          avatarId={meAvatar}
          onName={onMe}
          onPhoto={onMePhoto}
        />
        <NameField
          lang={lang}
          label={t(lang, "partnerName")}
          name={partnerName}
          avatarId={partnerAvatar}
          onName={onPartner}
          onPhoto={onPartnerPhoto}
        />
      </div>
      <div className="mt-auto flex gap-2 pt-10">
        <Button variant="outline" className="flex-1" onClick={onBack}>
          {t(lang, "cancel")}
        </Button>
        <Button className="flex-[2]" size="lg" onClick={onStart}>
          {t(lang, "start")}
        </Button>
      </div>
    </div>
  );
}

function NameField({
  lang,
  label,
  name,
  avatarId,
  onName,
  onPhoto,
}: {
  lang: Lang;
  label: string;
  name: string;
  avatarId?: string;
  onName: (v: string) => void;
  onPhoto: (f: File) => void;
}) {
  return (
    <label className="grid gap-2">
      <span className="text-sm font-medium text-subtle">{label}</span>
      <div className="flex items-center gap-3">
        <label className="relative cursor-pointer">
          <PersonAvatar name={name || label} avatarId={avatarId} className="size-14" />
          <input
            type="file"
            accept="image/*"
            className="sr-only"
            aria-label={t(lang, "myPhoto")}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onPhoto(f);
              e.target.value = "";
            }}
          />
        </label>
        <Input value={name} onChange={(e) => onName(e.target.value)} className="flex-1" />
      </div>
    </label>
  );
}
