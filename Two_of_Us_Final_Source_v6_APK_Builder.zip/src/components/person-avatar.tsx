import { cn } from "@/lib/utils";
import { useBlobUrl } from "@/lib/use-blob-url";

export function PersonAvatar({
  name,
  avatarId,
  className,
  ring,
}: {
  name: string;
  avatarId?: string;
  className?: string;
  ring?: boolean;
}) {
  const url = useBlobUrl(avatarId);
  const initial = (name.trim()[0] || "?").toUpperCase();
  return (
    <div
      className={cn(
        "relative shrink-0 overflow-hidden rounded-full bg-surface text-accent",
        ring && "ring-2 ring-accent ring-offset-2 ring-offset-bg",
        className,
      )}
    >
      {url ? (
        <img src={url} alt="" className="size-full object-cover" />
      ) : (
        <span className="grid size-full place-items-center font-display text-[0.9em] font-medium">
          {initial}
        </span>
      )}
    </div>
  );
}
