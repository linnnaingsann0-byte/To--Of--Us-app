import { useRef, useState } from "react";
import { Plus, Trash2, X } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BlobImage, BlobVideo } from "@/components/blob-media";
import { sendAlbumOverLink, useLink } from "@/components/link-provider";
import type { AlbumItem, Role } from "@/lib/types";
import { downloadBlob } from "@/lib/media";
import { blobGet } from "@/lib/idb";

export function PhotosView() {
  const photos = useApp((s) => s.photos);
  const settings = useApp((s) => s.settings);
  const addAlbum = useApp((s) => s.addAlbum);
  const lang = settings.lang;
  const p2p = useLink();
  const fileRef = useRef<HTMLInputElement>(null);
  const [filter, setFilter] = useState<"all" | Role>("all");
  const [open, setOpen] = useState<AlbumItem | null>(null);

  const list = photos.filter((p) => (filter === "all" ? true : p.from === filter));

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center justify-between px-4 py-4">
        <div>
          <h1 className="font-display text-2xl font-medium">{t(lang, "photos")}</h1>
          <p className="text-sm text-muted">{t(lang, "emptyPhotos")}</p>
        </div>
        <Button size="icon" aria-label={t(lang, "addPhoto")} onClick={() => fileRef.current?.click()}>
          <Plus className="size-5" />
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (!f) return;
            const item = await addAlbum("image", f, "", settings.activeRole);
            await sendAlbumOverLink(p2p, item);
          }}
        />
      </header>
      <div className="flex gap-2 px-4 pb-3">
        {(["all", "me", "partner"] as const).map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={cn(
              "h-8 rounded-full px-3 text-xs font-medium",
              filter === id ? "bg-accent text-accent-fg" : "bg-surface text-muted",
            )}
          >
            {id === "all" ? t(lang, "all") : id === "me" ? t(lang, "fromMe") : t(lang, "fromThem")}
          </button>
        ))}
      </div>
      {list.length === 0 ? (
        <EmptyPhotos lang={lang} />
      ) : (
        <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
            {list.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setOpen(p)}
                className="aspect-square overflow-hidden rounded-xl bg-surface"
              >
                <BlobImage id={p.blobId} alt={p.caption || t(lang, "photos")} className="size-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      )}
      {open ? <Lightbox item={open} kind="photos" onClose={() => setOpen(null)} /> : null}
    </div>
  );
}

function EmptyPhotos({ lang }: { lang: Parameters<typeof t>[0] }) {
  return (
    <div className="relative mx-4 mt-2 flex flex-1 flex-col overflow-hidden rounded-2xl">
      <img src="/empty-photos.jpg" alt="" className="absolute inset-0 size-full object-cover" />
      <div className="absolute inset-0 bg-bg/55" />
      <p className="relative m-auto max-w-xs px-6 text-center text-sm text-fg">{t(lang, "emptyPhotos")}</p>
    </div>
  );
}

export function Lightbox({
  item,
  kind,
  onClose,
}: {
  item: AlbumItem;
  kind: "photos" | "videos";
  onClose: () => void;
}) {
  const lang = useApp((s) => s.settings.lang);
  const updateCaption = useApp((s) => s.updateCaption);
  const removeAlbum = useApp((s) => s.removeAlbum);
  const [caption, setCaption] = useState(item.caption);

  return (
    <div className="fixed inset-0 z-40 flex flex-col bg-bg/95">
      <div className="flex items-center justify-between px-3 py-3">
        <Button variant="ghost" size="icon-sm" aria-label={t(lang, "close")} onClick={onClose}>
          <X className="size-5" />
        </Button>
        <div className="flex gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={t(lang, "download")}
            onClick={async () => {
              const blob = await blobGet(item.blobId);
              if (blob) downloadBlob(blob, item.kind === "video" ? "memory.mp4" : "memory.jpg");
            }}
          >
            <span className="text-xs font-medium">{t(lang, "download")}</span>
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={t(lang, "delete")}
            onClick={() => {
              void removeAlbum(kind, item.id);
              onClose();
            }}
          >
            <Trash2 className="size-4 text-danger" />
          </Button>
        </div>
      </div>
      <div className="flex min-h-0 flex-1 items-center justify-center px-3">
        {item.kind === "image" ? (
          <BlobImage id={item.blobId} alt={item.caption} className="max-h-full max-w-full rounded-xl object-contain" />
        ) : (
          <BlobVideo id={item.blobId} className="max-h-full max-w-full rounded-xl" />
        )}
      </div>
      <form
        className="flex gap-2 px-4 py-4 pb-[max(1rem,env(safe-area-inset-bottom))]"
        onSubmit={(e) => {
          e.preventDefault();
          updateCaption(kind, item.id, caption);
          onClose();
        }}
      >
        <Input
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          placeholder={t(lang, "caption")}
        />
        <Button type="submit">{t(lang, "save")}</Button>
      </form>
    </div>
  );
}
