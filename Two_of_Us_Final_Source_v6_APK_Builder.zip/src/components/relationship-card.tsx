import { useEffect, useState } from "react";
import { Bell, CalendarDays, Heart } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { relationshipDuration, isMonthlyAnniversary, monthsSince } from "@/lib/relationship";
import { cn } from "@/lib/utils";

export function RelationshipCard() {
  const settings = useApp((s) => s.settings);
  const patch = useApp((s) => s.patchSettings);
  const lang = settings.lang;
  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const id = window.setInterval(() => setNow(new Date()), 60_000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!settings.relationshipStartDate || !isMonthlyAnniversary(settings.relationshipStartDate, now)) return;
    const hour = settings.relationshipReminderHour ?? 9;
    if (now.getHours() !== hour) return;
    if (settings.relationshipReminder === false) return;

    const key = `two-of-us-anniversary-${settings.relationshipStartDate}-${now.getFullYear()}-${now.getMonth()}-${now.getDate()}`;
    if (localStorage.getItem(key)) return;
    localStorage.setItem(key, "1");

    const message = `${t(lang, "relationshipToday")} ${monthsSince(settings.relationshipStartDate, now)} ${t(lang, "relationshipMonths")}`;
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification("Two of Us 💕", { body: message, icon: "/favicon.svg" });
    }
  }, [settings.relationshipStartDate, settings.relationshipReminder, settings.relationshipReminderHour, lang, now]);

  if (!settings.relationshipStartDate) return null;
  const duration = relationshipDuration(settings.relationshipStartDate, now);
  if (!duration) return null;

  async function enableNotifications() {
    if (!("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    patch({ relationshipReminder: permission === "granted" });
  }

  return (
    <section className="mx-4 mt-4 overflow-hidden rounded-2xl border border-accent/30 bg-surface/85 shadow-sm">
      <div className="relative px-4 py-4">
        <div className="absolute -right-5 -top-5 text-accent/10">
          <Heart className="size-28 fill-current" />
        </div>
        <div className="relative">
          <div className="flex items-center gap-2 text-accent">
            <Heart className="size-4 fill-current" />
            <span className="text-xs font-semibold uppercase tracking-wider">{t(lang, "relationship")}</span>
          </div>

          <div className="mt-3 flex items-end gap-2">
            <strong className="font-display text-3xl leading-none">
              {duration.years > 0 ? `${duration.years} ${t(lang, "relationshipYears")} ` : ""}
              {duration.months} {t(lang, "relationshipMonths")}
            </strong>
            <span className="pb-0.5 text-sm text-muted">{duration.days} {t(lang, "relationshipDays")}</span>
          </div>

          <p className="mt-2 text-xs text-subtle">
            {new Date(settings.relationshipStartDate).toLocaleDateString(
              lang === "my" ? "my-MM" : lang === "th" ? "th-TH" : "en-US",
              { year: "numeric", month: "long", day: "numeric" },
            )}
          </p>

          {isMonthlyAnniversary(settings.relationshipStartDate, now) ? (
            <div className="mt-3 rounded-xl bg-accent/10 px-3 py-2 text-sm text-fg">
              {t(lang, "relationshipToday")} 🎉
            </div>
          ) : null}

          <button
            type="button"
            onClick={() => void enableNotifications()}
            className={cn(
              "mt-3 inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-medium",
              settings.relationshipReminder ? "border-accent/40 text-accent" : "border-border text-muted",
            )}
          >
            <Bell className="size-3.5" />
            {settings.relationshipReminder ? t(lang, "relationshipNotifyOn") : t(lang, "relationshipNotify")}
          </button>
        </div>
      </div>
    </section>
  );
}
