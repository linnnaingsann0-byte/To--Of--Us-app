import { useEffect, useState, type ReactNode } from "react";
import { CalendarDays, Check, Download, Image as ImageIcon, Share2, Upload } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { ACCENT_PRESETS, type Lang } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { PersonAvatar } from "@/components/person-avatar";
import { useBlobUrl } from "@/lib/use-blob-url";
import { useLink } from "@/components/link-provider";

export function SettingsView() {
  const settings = useApp((s) => s.settings);
  const patch = useApp((s) => s.patchSettings);
  const setPerson = useApp((s) => s.setPerson);
  const setAvatar = useApp((s) => s.setAvatar);
  const setWallpaper = useApp((s) => s.setWallpaper);
  const setChatWallpaper = useApp((s) => s.setChatWallpaper);
  const exportBackup = useApp((s) => s.exportBackup);
  const importBackup = useApp((s) => s.importBackup);
  const lang = settings.lang;
  const p2p = useLink();
  const wallpaperUrl = useBlobUrl(settings.wallpaperId);
  const chatWallpaperUrl = useBlobUrl(settings.chatWallpaperId);
  const [copied, setCopied] = useState(false);
  const [join, setJoin] = useState("");
  const [installEvent, setInstallEvent] = useState<any>(null);
  const online = p2p?.peers.some((p) => p.connectionState === "connected") ?? false;

  useEffect(() => {
    const handler = (e: Event) => { e.preventDefault(); setInstallEvent(e); };
    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  return (
    <div className="min-h-0 flex-1 overflow-y-auto px-4 py-4 pb-8">
      <h1 className="font-display text-2xl font-medium">{t(lang, "settings")}</h1>

      {installEvent ? <Section title={t(lang, "installApp")}>
        <Button className="w-full" onClick={async () => { await installEvent.prompt(); setInstallEvent(null); }}>{t(lang, "installAppNow")}</Button>
      </Section> : null}

      <Section title={t(lang, "language")}>
        <div className="grid grid-cols-3 gap-2">
          {(["my", "en", "th"] as Lang[]).map((code) => (
            <button
              key={code}
              type="button"
              onClick={() => patch({ lang: code })}
              className={cn(
                "h-11 rounded-lg border text-sm font-medium",
                lang === code ? "border-accent bg-accent/15 text-fg" : "border-border bg-surface text-muted",
              )}
            >
              {code === "my" ? t(lang, "myanmar") : code === "en" ? t(lang, "english") : t(lang, "thai")}
            </button>
          ))}
        </div>
      </Section>

      <Section title={t(lang, "whoAmI")}>
        <div className="grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => patch({ activeRole: "me" })}
            className={cn(
              "h-11 rounded-lg border text-sm font-medium",
              settings.activeRole === "me" ? "border-accent bg-accent/15" : "border-border bg-surface text-muted",
            )}
          >
            {t(lang, "iAmMe")}
          </button>
          <button
            type="button"
            onClick={() => patch({ activeRole: "partner" })}
            className={cn(
              "h-11 rounded-lg border text-sm font-medium",
              settings.activeRole === "partner" ? "border-accent bg-accent/15" : "border-border bg-surface text-muted",
            )}
          >
            {t(lang, "iAmPartner")}
          </button>
        </div>
        <p className="mt-2 text-xs text-subtle">{t(lang, "switchHint")}</p>
      </Section>

      <Section title={t(lang, "myName")}>
        <PersonRow
          name={settings.me.name}
          avatarId={settings.me.avatarId}
          onName={(v) => setPerson("me", { name: v })}
          onPhoto={(f) => void setAvatar("me", f)}
        />
      </Section>
      <Section title={t(lang, "partnerName")}>
        <PersonRow
          name={settings.partner.name}
          avatarId={settings.partner.avatarId}
          onName={(v) => setPerson("partner", { name: v })}
          onPhoto={(f) => void setAvatar("partner", f)}
        />
      </Section>

      <Section title={t(lang, "relationshipStart")}>
        <div className="rounded-xl border border-border bg-surface p-3">
          <div className="flex items-center gap-2">
            <CalendarDays className="size-4 text-accent" />
            <Input
              type="date"
              value={settings.relationshipStartDate || ""}
              onChange={(e) => patch({ relationshipStartDate: e.target.value })}
              className="flex-1"
            />
          </div>
          <p className="mt-2 text-xs text-subtle">{t(lang, "relationshipHint")}</p>
          <label className="mt-3 block text-xs text-subtle">{t(lang, "reminderTime")}
            <input type="time" value={`${String(settings.relationshipReminderHour ?? 9).padStart(2, "0")}:00`} onChange={(e) => patch({ relationshipReminderHour: Number(e.target.value.slice(0, 2)) })} className="mt-1 h-11 w-full rounded-lg border border-border bg-bg px-3 text-sm text-fg" />
          </label>
        </div>
      </Section>

      <Section title={t(lang, "coupleCode")}>
        <div className="flex items-center gap-2">
          <p className="flex-1 rounded-lg border border-border bg-surface px-3 py-2.5 font-display text-xl tracking-[0.3em]">
            {settings.coupleCode}
          </p>
          <Button
            variant="outline"
            onClick={async () => {
              await navigator.clipboard.writeText(settings.coupleCode);
              setCopied(true);
              setTimeout(() => setCopied(false), 1600);
            }}
          >
            {copied ? t(lang, "copied") : t(lang, "copyCode")}
          </Button>
        </div>
        <p className="mt-2 text-xs text-subtle">{t(lang, "shareHint")}</p>
        <p className="mt-2 text-xs text-muted">
          {online ? t(lang, "partnerOnline") : t(lang, "waitingPartner")}
        </p>
        <form
          className="mt-3 flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            const next = join.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
            if (next.length < 4 || next.length > 8) return;
            patch({ coupleCode: next });
            setJoin("");
          }}
        >
          <Input
            value={join}
            onChange={(e) => setJoin(e.target.value.toUpperCase())}
            placeholder={t(lang, "enterCode")}
            maxLength={8}
          />
          <Button type="submit" variant="outline">
            {t(lang, "applyCode")}
          </Button>
        </form>
      </Section>

      <Section title={t(lang, "themeColor")}>
        <p className="mb-3 text-xs text-subtle">{t(lang, "colorPresets")}</p>
        <div className="flex flex-wrap gap-3">
          {ACCENT_PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              aria-label={p.id}
              onClick={() => patch({ accent: p.hex })}
              className="size-10 rounded-full ring-offset-2 ring-offset-bg"
              style={{
                background: p.hex,
                boxShadow: settings.accent === p.hex ? `0 0 0 2px var(--fg)` : "0 0 0 1px var(--border)",
              }}
            >
              {settings.accent === p.hex ? <Check className="mx-auto size-4 text-accent-fg" /> : null}
            </button>
          ))}
          <label className="relative size-10 overflow-hidden rounded-full border border-border">
            <input
              type="color"
              value={settings.accent}
              aria-label={t(lang, "themeColor")}
              className="absolute inset-0 size-[150%] -translate-x-1/4 -translate-y-1/4 cursor-pointer"
              onChange={(e) => patch({ accent: e.target.value })}
            />
          </label>
        </div>
      </Section>

      <Section title={t(lang, "chatBackground")}>
        <p className="mb-3 text-xs text-subtle">{t(lang, "chatBackgroundHint")}</p>
        <div className="overflow-hidden rounded-xl border border-border bg-surface">
          <img src={chatWallpaperUrl || "/wallpaper.jpg"} alt="" className="h-36 w-full object-cover" />
        </div>
        <div className="mt-3 flex gap-2">
          <label className="flex-1">
            <span className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-accent text-sm font-medium text-accent-fg">
              <ImageIcon className="size-4" />{t(lang, "chooseChatBackground")}
            </span>
            <input type="file" accept="image/*" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) void setChatWallpaper(f); e.target.value = ""; }} />
          </label>
          <Button variant="outline" onClick={() => void setChatWallpaper(null)}>{t(lang, "resetBackground")}</Button>
        </div>
      </Section>

      <Section title={t(lang, "background")}>
        <p className="mb-3 text-xs text-subtle">{t(lang, "wallpaperHint")}</p>
        <div className="overflow-hidden rounded-xl">
          <img
            src={wallpaperUrl || "/wallpaper.jpg"}
            alt=""
            className="h-36 w-full object-cover"
          />
        </div>
        <div className="mt-3 flex gap-2">
          <label className="flex-1">
            <span className="inline-flex h-11 w-full items-center justify-center rounded-lg bg-accent text-sm font-medium text-accent-fg">
              {t(lang, "changeBackground")}
            </span>
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) void setWallpaper(f);
                e.target.value = "";
              }}
            />
          </label>
          <Button variant="outline" onClick={() => void setWallpaper(null)}>
            {t(lang, "resetBackground")}
          </Button>
        </div>
        <label className="mt-4 block">
          <span className="mb-2 block text-xs text-subtle">{t(lang, "backgroundDim")}</span>
          <input
            type="range"
            min={0.2}
            max={0.85}
            step={0.05}
            value={settings.wallpaperDim}
            onChange={(e) => patch({ wallpaperDim: Number(e.target.value) })}
            className="w-full accent-[var(--accent)]"
          />
        </label>
      </Section>
      <Section title={t(lang, "transferData")}>
        <p className="mb-3 text-xs text-subtle">{t(lang, "transferDataHint")}</p>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" onClick={async () => { const blob = await exportBackup(); const file = new File([blob], "two-of-us-backup.json", { type: "application/json" }); if (navigator.share && navigator.canShare?.({ files: [file] })) { await navigator.share({ title: "Two of Us backup", files: [file] }); } else { const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = file.name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000); } }}>
            <Share2 className="mr-2 size-4" />{t(lang, "shareBackup")}
          </Button>
          <label>
            <span className="inline-flex h-10 w-full items-center justify-center rounded-lg border border-border bg-surface text-sm font-medium text-fg"><Upload className="mr-2 size-4" />{t(lang, "restoreBackup")}</span>
            <input type="file" accept="application/json,.json" className="sr-only" onChange={async (e) => { const f = e.target.files?.[0]; if (f) { try { await importBackup(f); window.location.reload(); } catch { alert(t(lang, "backupInvalid")); } } e.target.value = ""; }} />
          </label>
        </div>
        <p className="mt-2 text-xs text-subtle"><Download className="mr-1 inline size-3" />{t(lang, "backupTip")}</p>
      </Section>

    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-8">
      <h2 className="mb-3 text-sm font-medium text-subtle">{title}</h2>
      {children}
    </section>
  );
}

function PersonRow({
  name,
  avatarId,
  onName,
  onPhoto,
}: {
  name: string;
  avatarId?: string;
  onName: (v: string) => void;
  onPhoto: (f: File) => void;
}) {
  return (
    <div className="flex items-center gap-3">
      <label className="cursor-pointer">
        <PersonAvatar name={name} avatarId={avatarId} className="size-12" />
        <input
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onPhoto(f);
            e.target.value = "";
          }}
        />
      </label>
      <Input value={name} onChange={(e) => onName(e.target.value)} />
    </div>
  );
}
