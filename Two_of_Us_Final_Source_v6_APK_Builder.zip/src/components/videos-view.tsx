import { useRef, useState } from "react";
import { Plus } from "lucide-react";
import { useApp } from "@/lib/store";
import { t } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { BlobVideo } from "@/components/blob-media";
import { Lightbox } from "@/components/photos-view";
import { sendAlbumOverLink, useLink } from "@/components/link-provider";
import type { AlbumItem, Role } from "@/lib/types";

export function VideosView() {
  const videos = useApp((s) => s.videos);
  const settings = useApp((s) => s.settings);
  const addAlbum = useApp((s) => s.addAlbum);
  const lang = settings.lang;
  const p2p = useLink();
  const fileRef = useRef<HTMLInputElement>(null);
  const [filter, setFilter] = useState<"all" | Role>("all");
  const [open, setOpen] = useState<AlbumItem | null>(null);
  const list = videos.filter((p) => (filter === "all" ? true : p.from === filter));

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <header className="flex items-center justify-between px-4 py-4">
        <div>
          <h1 className="font-display text-2xl font-medium">{t(lang, "videos")}</h1>
          <p className="text-sm text-muted">{t(lang, "emptyVideos")}</p>
        </div>
        <Button size="icon" aria-label={t(lang, "addVideo")} onClick={() => fileRef.current?.click()}>
          <Plus className="size-5" />
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept="video/*"
          className="sr-only"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (!f) return;
            const item = await addAlbum("video", f, "", settings.activeRole);
            await sendAlbumOverLink(p2p, item);
          }}
        />
      </header>
      <div className="flex gap-2 px-4 pb-3">
        {(["all", "me", "partner"] as const).map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => setFilter(id)}
            className={cn(
              "h-8 rounded-full px-3 text-xs font-medium",
              filter === id ? "bg-accent text-accent-fg" : "bg-surface text-muted",
            )}
          >
            {id === "all" ? t(lang, "all") : id === "me" ? t(lang, "fromMe") : t(lang, "fromThem")}
          </button>
        ))}
      </div>
      {list.length === 0 ? (
        <div className="relative mx-4 mt-2 flex flex-1 flex-col overflow-hidden rounded-2xl">
          <img src="/empty-videos.jpg" alt="" className="absolute inset-0 size-full object-cover" />
          <div className="absolute inset-0 bg-bg/55" />
          <p className="relative m-auto max-w-xs px-6 text-center text-sm text-fg">{t(lang, "emptyVideos")}</p>
        </div>
      ) : (
        <div className="min-h-0 flex-1 overflow-y-auto px-3 pb-4">
          <div className="grid grid-cols-1 gap-3">
            {list.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setOpen(p)}
                className="overflow-hidden rounded-xl bg-surface text-left"
              >
                <BlobVideo id={p.blobId} className="aspect-video w-full object-cover" controls={false} muted />
                {p.caption ? <p className="px-3 py-2 text-sm text-muted">{p.caption}</p> : null}
              </button>
            ))}
          </div>
        </div>
      )}
      {open ? <Lightbox item={open} kind="videos" onClose={() => setOpen(null)} /> : null}
    </div>
  );
}
