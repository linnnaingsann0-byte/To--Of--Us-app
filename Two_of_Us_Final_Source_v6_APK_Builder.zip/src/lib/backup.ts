import { blobGet, blobPut, kvGet, kvSet } from "./idb";

const KV_KEYS = ["settings", "messages", "photos", "videos", "notes"] as const;

type Backup = {
  format: "two-of-us-backup";
  version: 1;
  exportedAt: string;
  data: Record<string, unknown>;
  blobs: Record<string, { type: string; data: string }>;
};

function toBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] || "");
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

function fromBase64(value: string, type: string) {
  const bytes = Uint8Array.from(atob(value), (c) => c.charCodeAt(0));
  return new Blob([bytes], { type });
}

function collectBlobIds(data: Record<string, unknown>) {
  const ids = new Set<string>();
  const walk = (value: unknown) => {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) return value.forEach(walk);
    const record = value as Record<string, unknown>;
    for (const [key, child] of Object.entries(record)) {
      if (["blobId", "mediaId", "avatarId", "wallpaperId", "chatWallpaperId"].includes(key) && typeof child === "string") {
        ids.add(child);
      } else walk(child);
    }
  };
  walk(data);
  return [...ids];
}

export async function exportBackup(): Promise<Blob> {
  const data: Record<string, unknown> = {};
  for (const key of KV_KEYS) data[key] = (await kvGet(key)) ?? null;
  const blobs: Backup["blobs"] = {};
  for (const id of collectBlobIds(data)) {
    const blob = await blobGet(id);
    if (blob) blobs[id] = { type: blob.type || "application/octet-stream", data: await toBase64(blob) };
  }
  const backup: Backup = { format: "two-of-us-backup", version: 1, exportedAt: new Date().toISOString(), data, blobs };
  return new Blob([JSON.stringify(backup)], { type: "application/json" });
}

export async function importBackup(file: File) {
  const raw = JSON.parse(await file.text()) as Backup;
  if (raw?.format !== "two-of-us-backup" || raw.version !== 1) throw new Error("Invalid backup");
  for (const [key, value] of Object.entries(raw.data || {})) await kvSet(key, value);
  for (const [id, item] of Object.entries(raw.blobs || {})) await blobPut(id, fromBase64(item.data, item.type));
}
