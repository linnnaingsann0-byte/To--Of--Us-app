import { useCallback, useEffect, useRef, useState } from "react";
import { P2PRoom, type PeerInfo } from "./p2p";

export interface UseP2PRoomOptions {
  room?: string;
  name?: string;
  enabled?: boolean;
}

export interface P2PRoomHandle {
  selfId: string;
  room: string;
  peers: PeerInfo[];
  joined: boolean;
  broadcast: (data: unknown) => void;
  send: (data: unknown, peerId?: string) => void;
  onMessage: (
    fn: (from: string, data: unknown, channel: "state" | "reliable") => void,
  ) => () => void;
  setLocalStream: (stream: MediaStream | null) => void;
  replaceTrack: (kind: "audio" | "video", track: MediaStreamTrack | null) => void;
  onTrack: (fn: (from: string, event: RTCTrackEvent) => void) => () => void;
}

function defaultRoom(): string {
  if (typeof window === "undefined") return "room-ssr";
  return `room-${window.location.hostname.split(".")[0]}`.slice(0, 64);
}

export function useP2PRoom(options: UseP2PRoomOptions = {}): P2PRoomHandle {
  const enabled = options.enabled !== false;
  const [selfId] = useState(() => `p-${Math.random().toString(36).slice(2, 10)}`);
  const [room] = useState(() => options.room ?? defaultRoom());
  const [name] = useState(() => options.name ?? selfId);
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [joined, setJoined] = useState(false);
  const roomRef = useRef<P2PRoom | null>(null);
  const listeners = useRef(
    new Set<(from: string, data: unknown, channel: "state" | "reliable") => void>(),
  );
  const trackListeners = useRef(new Set<(from: string, event: RTCTrackEvent) => void>());

  useEffect(() => {
    if (!enabled) return;
    const p2p = new P2PRoom({
      room,
      selfId,
      name,
      onPeersChanged: setPeers,
      onMessage: (from, data, channel) => {
        for (const fn of listeners.current) fn(from, data, channel);
      },
      onConnected: () => setJoined(true),
      onTrack: (from, event) => {
        for (const fn of trackListeners.current) fn(from, event);
      },
    });
    roomRef.current = p2p;
    void p2p.join();
    return () => {
      roomRef.current = null;
      p2p.close();
    };
  }, [room, selfId, name, enabled]);

  const broadcast = useCallback((data: unknown) => roomRef.current?.broadcast(data), []);
  const send = useCallback(
    (data: unknown, peerId?: string) => roomRef.current?.send(data, peerId),
    [],
  );
  const onMessage = useCallback(
    (fn: (from: string, data: unknown, channel: "state" | "reliable") => void) => {
      listeners.current.add(fn);
      return () => {
        listeners.current.delete(fn);
      };
    },
    [],
  );
  const setLocalStream = useCallback((stream: MediaStream | null) => {
    roomRef.current?.setLocalStream(stream);
  }, []);
  const replaceTrack = useCallback((kind: "audio" | "video", track: MediaStreamTrack | null) => {
    roomRef.current?.replaceTrack(kind, track);
  }, []);
  const onTrack = useCallback((fn: (from: string, event: RTCTrackEvent) => void) => {
    trackListeners.current.add(fn);
    return () => {
      trackListeners.current.delete(fn);
    };
  }, []);

  return {
    selfId,
    room,
    peers,
    joined,
    broadcast,
    send,
    onMessage,
    setLocalStream,
    replaceTrack,
    onTrack,
  };
}
