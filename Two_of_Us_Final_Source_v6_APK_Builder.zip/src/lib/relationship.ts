export interface RelationshipDuration {
  years: number;
  months: number;
  days: number;
  totalMonths: number;
  totalDays: number;
}

function parseDate(value: string) {
  const [y, m, d] = value.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function relationshipDuration(startDate: string, now = new Date()): RelationshipDuration | null {
  if (!startDate) return null;
  const start = parseDate(startDate);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  if (start > today) return null;

  let years = today.getFullYear() - start.getFullYear();
  let months = today.getMonth() - start.getMonth();
  let days = today.getDate() - start.getDate();

  if (days < 0) {
    months -= 1;
    const previousMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
    days += previousMonthEnd.getDate();
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const totalMonths =
    (today.getFullYear() - start.getFullYear()) * 12 +
    (today.getMonth() - start.getMonth()) -
    (today.getDate() < start.getDate() ? 1 : 0);

  const msPerDay = 24 * 60 * 60 * 1000;
  const totalDays = Math.floor((today.getTime() - start.getTime()) / msPerDay);
  return { years, months, days, totalMonths: Math.max(0, totalMonths), totalDays };
}

export function isMonthlyAnniversary(startDate: string, now = new Date()) {
  if (!startDate) return false;
  const start = parseDate(startDate);
  return start <= now && start.getDate() === now.getDate();
}

export function monthsSince(startDate: string, now = new Date()) {
  const d = relationshipDuration(startDate, now);
  return d?.totalMonths ?? 0;
}
