export function startRingtone(): () => void {
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AudioCtx();
  let stopped = false;
  let timer = 0;

  const ping = (freq: number, at: number, dur = 0.28) => {
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    osc.connect(g);
    g.connect(ctx.destination);
    const t0 = ctx.currentTime + at;
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(0.07, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.start(t0);
    osc.stop(t0 + dur + 0.02);
  };

  const loop = () => {
    if (stopped) return;
    ping(523.25, 0);
    ping(659.25, 0.32);
    timer = window.setTimeout(loop, 1700);
  };
  void ctx.resume();
  loop();

  return () => {
    stopped = true;
    window.clearTimeout(timer);
    void ctx.close();
  };
}
