import { create } from "zustand";
import {
  ACCENT_PRESETS,
  DEFAULT_SETTINGS,
  type AlbumItem,
  type CallKind,
  type CallState,
  type Message,
  type Note,
  type Role,
  type Settings,
  type Tab,
} from "./types";
import { blobDel, blobPut, blobUrlForget, kvGet, kvSet } from "./idb";
import { coupleCode, uid } from "./utils";
import { compressImage } from "./media";
import { exportBackup as makeBackup, importBackup as loadBackup } from "./backup";

interface AppState {
  ready: boolean;
  tab: Tab;
  settings: Settings;
  messages: Message[];
  photos: AlbumItem[];
  videos: AlbumItem[];
  notes: Note[];
  call: CallState;
  hydrate: () => Promise<void>;
  setTab: (tab: Tab) => void;
  patchSettings: (partial: Partial<Settings>) => void;
  setPerson: (role: Role, partial: Partial<Settings["me"]>) => void;
  setAvatar: (role: Role, file: File) => Promise<void>;
  setWallpaper: (file: File | null) => Promise<void>;
  setChatWallpaper: (file: File | null) => Promise<void>;
  exportBackup: () => Promise<Blob>;
  importBackup: (file: File) => Promise<void>;
  sendMessage: (text: string, media?: { blob: Blob; kind: "image" | "video" }, replyToId?: string) => Promise<Message>;
  deleteMessage: (messageId: string) => void;
  ingestRemoteMessage: (msg: Message, mediaDataUrl?: string) => Promise<void>;
  saveMessageMedia: (messageId: string) => Promise<void>;
  addAlbum: (kind: "image" | "video", file: File, caption: string, from: Role) => Promise<AlbumItem>;
  updateCaption: (kind: "photos" | "videos", id: string, caption: string) => void;
  removeAlbum: (kind: "photos" | "videos", id: string) => Promise<void>;
  addNote: (title: string, body: string) => Note;
  updateNote: (id: string, patch: Partial<Pick<Note, "title" | "body" | "pinned">>) => void;
  removeNote: (id: string) => void;
  applyRemoteNotes: (notes: Note[]) => void;
  applyRemoteAlbum: (item: AlbumItem, dataUrl: string) => Promise<void>;
  startCall: (kind: CallKind) => void;
  receiveCall: (kind: CallKind) => void;
  acceptCall: () => void;
  endCall: () => void;
}

async function persistAll(get: () => AppState) {
  const { settings, messages, photos, videos, notes } = get();
  await Promise.all([
    kvSet("settings", settings),
    kvSet("messages", messages),
    kvSet("photos", photos),
    kvSet("videos", videos),
    kvSet("notes", notes),
  ]);
}

export const useApp = create<AppState>((set, get) => ({
  ready: false,
  tab: "chat",
  settings: { ...DEFAULT_SETTINGS, coupleCode: "" },
  messages: [],
  photos: [],
  videos: [],
  notes: [],
  call: { phase: "idle", kind: "audio" },

  hydrate: async () => {
    const [settings, messages, photos, videos, notes] = await Promise.all([
      kvGet<Settings>("settings"),
      kvGet<Message[]>("messages"),
      kvGet<AlbumItem[]>("photos"),
      kvGet<AlbumItem[]>("videos"),
      kvGet<Note[]>("notes"),
    ]);
    const next: Settings = {
      ...DEFAULT_SETTINGS,
      ...(settings ?? {}),
      me: { ...DEFAULT_SETTINGS.me, ...(settings?.me ?? {}) },
      partner: { ...DEFAULT_SETTINGS.partner, ...(settings?.partner ?? {}) },
      coupleCode: settings?.coupleCode || coupleCode(),
    };
    if (!ACCENT_PRESETS.some((p) => p.hex === next.accent) && !/^#[0-9a-fA-F]{6}$/.test(next.accent)) {
      next.accent = DEFAULT_SETTINGS.accent;
    }
    set({
      settings: next,
      messages: messages ?? [],
      photos: photos ?? [],
      videos: videos ?? [],
      notes: notes ?? [],
      ready: true,
    });
    if (!settings) await kvSet("settings", next);
  },

  setTab: (tab) => set({ tab }),

  patchSettings: (partial) => {
    set((s) => ({ settings: { ...s.settings, ...partial } }));
    void persistAll(get);
  },

  setPerson: (role, partial) => {
    set((s) => ({
      settings: {
        ...s.settings,
        [role]: { ...s.settings[role], ...partial },
      },
    }));
    void persistAll(get);
  },

  setAvatar: async (role, file) => {
    const blob = await compressImage(file, 480, 0.85);
    const id = uid("ava");
    await blobPut(id, blob);
    const prev = get().settings[role].avatarId;
    set((s) => ({
      settings: { ...s.settings, [role]: { ...s.settings[role], avatarId: id } },
    }));
    if (prev) {
      blobUrlForget(prev);
      void blobDel(prev);
    }
    void persistAll(get);
  },

  setWallpaper: async (file) => {
    const prev = get().settings.wallpaperId;
    if (!file) {
      set((s) => ({ settings: { ...s.settings, wallpaperId: undefined } }));
      if (prev) {
        blobUrlForget(prev);
        void blobDel(prev);
      }
      void persistAll(get);
      return;
    }
    const blob = await compressImage(file, 1800, 0.8);
    const id = uid("wall");
    await blobPut(id, blob);
    set((s) => ({ settings: { ...s.settings, wallpaperId: id } }));
    if (prev) {
      blobUrlForget(prev);
      void blobDel(prev);
    }
    void persistAll(get);
  },

  setChatWallpaper: async (file) => {
    const prev = get().settings.chatWallpaperId;
    if (!file) {
      set((s) => ({ settings: { ...s.settings, chatWallpaperId: undefined } }));
      if (prev) { blobUrlForget(prev); void blobDel(prev); }
      void persistAll(get);
      return;
    }
    const blob = await compressImage(file, 1800, 0.78);
    const id = uid("chatwall");
    await blobPut(id, blob);
    set((s) => ({ settings: { ...s.settings, chatWallpaperId: id } }));
    if (prev) { blobUrlForget(prev); void blobDel(prev); }
    void persistAll(get);
  },

  exportBackup: () => makeBackup(),

  importBackup: async (file) => {
    await loadBackup(file);
    const [settings, messages, photos, videos, notes] = await Promise.all([
      kvGet<Settings>("settings"), kvGet<Message[]>("messages"), kvGet<AlbumItem[]>("photos"),
      kvGet<AlbumItem[]>("videos"), kvGet<Note[]>("notes"),
    ]);
    if (!settings) throw new Error("Invalid backup");
    set({ settings: { ...DEFAULT_SETTINGS, ...settings }, messages: messages ?? [], photos: photos ?? [], videos: videos ?? [], notes: notes ?? [] });
  },

  sendMessage: async (text, media, replyToId) => {
    const { settings } = get();
    let mediaId: string | undefined;
    let mediaKind: Message["mediaKind"];
    if (media) {
      const blob = media.kind === "image" ? await compressImage(media.blob) : media.blob;
      mediaId = uid("med");
      await blobPut(mediaId, blob);
      mediaKind = media.kind;
    }
    const msg: Message = {
      id: uid("msg"),
      from: settings.activeRole,
      text: text.trim(),
      mediaId,
      mediaKind,
      createdAt: Date.now(),
      replyToId,
    };
    set((s) => ({ messages: [...s.messages, msg] }));
    void persistAll(get);
    return msg;
  },

  deleteMessage: (messageId) => {
    const now = Date.now();
    set((s) => ({ messages: s.messages.map((m) => (m.id === messageId ? { ...m, deletedAt: now } : m)) }));
    void persistAll(get);
  },

  ingestRemoteMessage: async (msg, mediaDataUrl) => {
    if (get().messages.some((m) => m.id === msg.id)) return;
    if (mediaDataUrl && msg.mediaId) {
      const { dataUrlToBlob } = await import("./media");
      await blobPut(msg.mediaId, dataUrlToBlob(mediaDataUrl));
    }
    set((s) => ({ messages: [...s.messages, msg].sort((a, b) => a.createdAt - b.createdAt) }));
    void persistAll(get);
  },

  saveMessageMedia: async (messageId) => {
    const msg = get().messages.find((m) => m.id === messageId);
    if (!msg?.mediaId || !msg.mediaKind) return;
    const item: AlbumItem = {
      id: uid("alb"),
      blobId: msg.mediaId,
      kind: msg.mediaKind,
      caption: msg.text,
      createdAt: msg.createdAt,
      from: msg.from,
    };
    if (msg.mediaKind === "image") {
      set((s) => ({
        photos: [item, ...s.photos],
        messages: s.messages.map((m) => (m.id === messageId ? { ...m, saved: true } : m)),
      }));
    } else {
      set((s) => ({
        videos: [item, ...s.videos],
        messages: s.messages.map((m) => (m.id === messageId ? { ...m, saved: true } : m)),
      }));
    }
    void persistAll(get);
  },

  addAlbum: async (kind, file, caption, from) => {
    const blob = kind === "image" ? await compressImage(file) : file;
    const blobId = uid("med");
    await blobPut(blobId, blob);
    const item: AlbumItem = {
      id: uid("alb"),
      blobId,
      kind,
      caption,
      createdAt: Date.now(),
      from,
    };
    if (kind === "image") set((s) => ({ photos: [item, ...s.photos] }));
    else set((s) => ({ videos: [item, ...s.videos] }));
    void persistAll(get);
    return item;
  },

  updateCaption: (kind, id, caption) => {
    set((s) => ({
      [kind]: s[kind].map((it) => (it.id === id ? { ...it, caption } : it)),
    }));
    void persistAll(get);
  },

  removeAlbum: async (kind, id) => {
    const list = get()[kind];
    const item = list.find((x) => x.id === id);
    set((s) => ({ [kind]: s[kind].filter((x) => x.id !== id) }));
    if (item) {
      const stillUsed =
        get().messages.some((m) => m.mediaId === item.blobId) ||
        get().photos.some((p) => p.blobId === item.blobId) ||
        get().videos.some((p) => p.blobId === item.blobId);
      if (!stillUsed) {
        blobUrlForget(item.blobId);
        void blobDel(item.blobId);
      }
    }
    void persistAll(get);
  },

  addNote: (title, body) => {
    const note: Note = {
      id: uid("note"),
      title: title.trim() || "",
      body: body.trim(),
      pinned: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    set((s) => ({ notes: [note, ...s.notes] }));
    void persistAll(get);
    return note;
  },

  updateNote: (id, patch) => {
    set((s) => ({
      notes: s.notes.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n)),
    }));
    void persistAll(get);
  },

  removeNote: (id) => {
    set((s) => ({ notes: s.notes.filter((n) => n.id !== id) }));
    void persistAll(get);
  },

  applyRemoteNotes: (notes) => {
    set((s) => {
      const map = new Map(s.notes.map((n) => [n.id, n]));
      for (const n of notes) {
        const existing = map.get(n.id);
        if (!existing || n.updatedAt >= existing.updatedAt) map.set(n.id, n);
      }
      return { notes: [...map.values()].sort((a, b) => b.updatedAt - a.updatedAt) };
    });
    void persistAll(get);
  },

  applyRemoteAlbum: async (item, dataUrl) => {
    const exists =
      get().photos.some((p) => p.id === item.id) || get().videos.some((v) => v.id === item.id);
    if (exists) return;
    const { dataUrlToBlob } = await import("./media");
    await blobPut(item.blobId, dataUrlToBlob(dataUrl));
    if (item.kind === "image") set((s) => ({ photos: [item, ...s.photos] }));
    else set((s) => ({ videos: [item, ...s.videos] }));
    void persistAll(get);
  },

  startCall: (kind) => set({ call: { phase: "outgoing", kind } }),
  receiveCall: (kind) => set({ call: { phase: "incoming", kind } }),
  acceptCall: () => set({ call: { phase: "active", kind: get().call.kind, startedAt: Date.now() } }),
  endCall: () => set({ call: { phase: "idle", kind: get().call.kind } }),
}));
