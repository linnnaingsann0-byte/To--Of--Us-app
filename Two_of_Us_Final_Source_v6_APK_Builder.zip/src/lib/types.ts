export type Lang = "en" | "my" | "th";
export type Role = "me" | "partner";
export type Tab = "chat" | "photos" | "videos" | "notes" | "settings";
export type MediaKind = "image" | "video";

export interface Person {
  name: string;
  avatarId?: string;
}

export interface Message {
  id: string;
  from: Role;
  text: string;
  mediaId?: string;
  mediaKind?: MediaKind;
  createdAt: number;
  saved?: boolean;
  replyToId?: string;
  deletedAt?: number;
}

export interface AlbumItem {
  id: string;
  blobId: string;
  kind: MediaKind;
  caption: string;
  createdAt: number;
  from: Role;
}

export interface Note {
  id: string;
  title: string;
  body: string;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
}

export interface Settings {
  lang: Lang;
  accent: string;
  wallpaperId?: string;
  chatWallpaperId?: string;
  wallpaperDim: number;
  coupleCode: string;
  me: Person;
  partner: Person;
  activeRole: Role;
  onboarded: boolean;
  relationshipStartDate?: string;
  relationshipReminder?: boolean;
  relationshipReminderHour?: number;
}

export type CallKind = "audio" | "video";
export type CallPhase = "idle" | "outgoing" | "incoming" | "active";

export interface CallState {
  phase: CallPhase;
  kind: CallKind;
  startedAt?: number;
}

export const ACCENT_PRESETS = [
  { id: "rose", hex: "#c45c6a" },
  { id: "clay", hex: "#b5694a" },
  { id: "sage", hex: "#5f7f68" },
  { id: "ocean", hex: "#4a7384" },
  { id: "ink", hex: "#8a827a" },
] as const;

export const DEFAULT_SETTINGS: Settings = {
  lang: "my",
  accent: "#c45c6a",
  wallpaperDim: 0.55,
  chatWallpaperId: undefined,
  coupleCode: "",
  me: { name: "" },
  partner: { name: "" },
  activeRole: "me",
  onboarded: false,
  relationshipReminder: true,
  relationshipReminderHour: 9,
};
