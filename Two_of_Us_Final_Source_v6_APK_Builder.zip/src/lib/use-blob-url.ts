import { useEffect, useState } from "react";
import { blobUrl } from "./idb";

export function useBlobUrl(id?: string) {
  const [url, setUrl] = useState<string>();
  useEffect(() => {
    if (!id) {
      setUrl(undefined);
      return;
    }
    let live = true;
    void blobUrl(id).then((u) => {
      if (live) setUrl(u);
    });
    return () => {
      live = false;
    };
  }, [id]);
  return url;
}
