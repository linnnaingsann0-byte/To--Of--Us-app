import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function uid(prefix = "id"): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}

export function coupleCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += alphabet[Math.floor(Math.random() * alphabet.length)];
  return out;
}

export function accentForeground(hex: string): string {
  const raw = hex.replace("#", "");
  if (raw.length !== 6) return "#f3ece4";
  const n = parseInt(raw, 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  const l = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return l > 0.62 ? "#14110f" : "#f3ece4";
}

export const LOCALE: Record<"en" | "my" | "th", string> = {
  en: "en-US",
  my: "my-MM",
  th: "th-TH",
};

export function formatTime(ts: number, lang: "en" | "my" | "th"): string {
  return new Intl.DateTimeFormat(LOCALE[lang], { hour: "numeric", minute: "2-digit" }).format(ts);
}

export function formatDay(ts: number, lang: "en" | "my" | "th"): string {
  const d = new Date(ts);
  const now = new Date();
  const start = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = start(now) - start(d);
  if (diff === 0) return lang === "my" ? "ယနေ့" : lang === "th" ? "วันนี้" : "Today";
  if (diff === 86400000) return lang === "my" ? "မနေ့က" : lang === "th" ? "เมื่อวาน" : "Yesterday";
  return new Intl.DateTimeFormat(LOCALE[lang], { month: "short", day: "numeric", year: "numeric" }).format(d);
}

export function formatDuration(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${String(m).padStart(2, "0")}:${String(r).padStart(2, "0")}`;
}
