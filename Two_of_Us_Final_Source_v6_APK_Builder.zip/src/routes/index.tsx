import { useEffect } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { useApp } from "@/lib/store";
import { Onboarding } from "@/components/onboarding";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const ready = useApp((s) => s.ready);
  const onboarded = useApp((s) => s.settings.onboarded);
  const hydrate = useApp((s) => s.hydrate);

  useEffect(() => {
    void hydrate();
  }, [hydrate]);

  if (!ready) {
    return (
      <main className="grid min-h-dvh place-items-center bg-bg text-fg">
        <div className="flex flex-col items-center gap-3">
          <Heart className="size-7 fill-accent text-accent" strokeWidth={1.5} />
          <p className="font-display text-2xl">Two of Us</p>
        </div>
      </main>
    );
  }

  if (!onboarded) return <Onboarding />;
  return <AppShell />;
}
